# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2015 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
""" This module provides classes with methods to handle netlink notifications.
"""
from __future__ import absolute_import

import collections
import greenlet
import os
import socket
import struct
import sys

import eventlet
import eventlet.pools
from nlmanager import nlpacket
from nlmanager.nlpacket import (
    NLM_F_DUMP,
    NLM_F_REQUEST,
    RTM_DELADDR,
    RTM_DELLINK,
    RTM_DELROUTE,
    RTM_DELNEIGH,
    RTM_GETADDR,
    RTM_GETNEIGH,
    RTM_GETROUTE,
    RTM_GETLINK,
    RTM_NEWADDR,
    RTM_NEWLINK,
    RTM_NEWNEIGH,
    RTM_NEWROUTE,
    RTMGRP_IPV4_IFADDR,
    RTMGRP_IPV6_ROUTE,
    RTMGRP_IPV6_IFADDR,
    RTMGRP_IPV4_ROUTE,
    RTMGRP_LINK,
    RTMGRP_NEIGH
)

from netq.common.enums import (
    InterfaceState,
    LinkType,
    NeighborState
)


class Address(object):

    def __init__(self, ifindex, prefix, mask, family):
        self.ifindex = ifindex
        self.prefix = prefix
        self.mask = mask
        self.is_ipv6 = family == socket.AF_INET6


class Link(object):

    def __init__(self, family, ifindex, master_ifindex, ifname, admin_state,
                 oper_state, mac_addr, kind=None, mtu=1500, dstport=0,
                 localip='', vni=0):
        self.family = family
        self.ifindex = ifindex
        self.ifname = ifname
        self.admin_state = admin_state
        self.oper_state = oper_state
        self.mac_addr = mac_addr
        if kind == 'ignore':
            self.kind = ''
        else:
            self.kind = kind
        self.mtu = mtu
        self.master_ifindex = master_ifindex
        self.dstport = dstport
        self.localip = localip
        self.vni = int(vni)


class Neighbor(object):

    def __init__(self, ifindex, ip_address, mac_address, vlan, port, state,
                 family):
        self.ifindex = ifindex
        self.is_ipv6 = family == socket.AF_INET6
        self.ip_address = str(ip_address)
        self.mac_address = mac_address
        self.state = state
        self.family = family
        self.vlan = vlan
        self.port = port


class Route(object):

    def __init__(self, origin, ip_address, nexthops, protocol, src, family,
                 table):
        self.ifindex = Netlink.DUMMY_IFINDEX
        self.origin = origin
        self.ip_address = ip_address
        self.is_ipv6 = family == socket.AF_INET6
        self.nexthops = nexthops
        self.protocol = protocol
        self.src = src
        self.table = table

    @staticmethod
    def get_nexthops(msg):
        nexthop = msg.get_attribute_value(msg.RTA_GATEWAY)
        multipath = msg.get_attribute_value(msg.RTA_MULTIPATH)
        nexthops = []
        if nexthop:
            rta_oif = msg.get_attribute_value(msg.RTA_OIF)
            nexthops.append((nexthop, rta_oif))
        elif multipath:
            for (nexthop, rtnh_ifindex, rtnh_flags, rtnh_hops) in multipath:
                nexthops.append((nexthop, rtnh_ifindex))
        return nexthops


class NetlinkStat(object):

    RTM_NEWFDB = 'RTM_NEWFDB'
    RTM_DELFDB = 'RTM_DELFDB'

    str_map = {
        RTM_NEWLINK: 'RTM_NEWLINK',
        RTM_DELLINK: 'RTM_DELLINK',
        RTM_NEWNEIGH: 'RTM_NEWNEIGH',
        RTM_DELNEIGH: 'RTM_DELNEIGH',
        RTM_NEWROUTE: 'RTM_NEWROUTE',
        RTM_DELROUTE: 'RTM_DELROUTE',
        RTM_NEWADDR: 'RTM_NEWADDR',
        RTM_DELADDR: 'RTM_DELADDR',
        RTM_NEWFDB: 'RTM_NEWFDB',
        RTM_DELFDB: 'RTM_DELFDB'
    }

    ALL = [RTM_NEWLINK, RTM_DELLINK, RTM_NEWNEIGH, RTM_DELNEIGH,
           RTM_NEWROUTE, RTM_DELROUTE, RTM_NEWADDR, RTM_DELADDR,
           RTM_NEWFDB, RTM_DELFDB]

    def __init__(self):
        self.stats = None

    def __repr__(self):
        return repr({self.str_map[k]: v for k, v in self.stats.iteritems()})

    def increment(self, msg_type, count):
        self.stats[msg_type] += count

    def reset(self):
        self.stats = {stat: 0 for stat in NetlinkStat.ALL}


class Netlink(object):
    """ Provides methods to parse RTNL messages and invoke callbacks based on
    the message type.
    """
    # pylint: disable=too-many-instance-attributes
    __BUF_SIZE = 90 * 1024 * 1024
    __NETLINK_NO_ENOBUFS = 5
    __NLMSG_FMT = 'IHHII'
    __NLMSG_LEN = struct.calcsize(__NLMSG_FMT)
    __SO_RCVBUFFORCE = 33
    __SOL_NETLINK = 270

    DUMMY_IFINDEX = 0
    GROUPS = (RTMGRP_LINK | RTMGRP_NEIGH | RTMGRP_IPV4_IFADDR |
              RTMGRP_IPV4_ROUTE | RTMGRP_IPV6_IFADDR | RTMGRP_IPV6_ROUTE)
    NETLINK_ROUTE = 0            # Routing/device hook
    NLSOCK_BYTES = 8 * 1024

    NEWADDR = RTM_NEWADDR
    DELADDR = RTM_DELADDR
    NEWLINK = RTM_NEWLINK
    DELLINK = RTM_DELLINK
    NEWNEIGH = RTM_NEWNEIGH
    DELNEIGH = RTM_DELNEIGH
    NEWROUTE = RTM_NEWROUTE
    DELROUTE = RTM_DELROUTE

    IFA_ADDRESS = nlpacket.Address.IFA_ADDRESS
    IFF_SLAVE = nlpacket.Link.IFF_SLAVE
    IFLA_ADDRESS = nlpacket.Link.IFLA_ADDRESS
    IFLA_IFNAME = nlpacket.Link.IFLA_IFNAME
    IFLA_LINKINFO = nlpacket.Link.IFLA_LINKINFO
    IFLA_MASTER = nlpacket.Link.IFLA_MASTER
    IFLA_CARRIER = nlpacket.Link.IFLA_CARRIER
    IFLA_MTU = nlpacket.Link.IFLA_MTU
    IFLA_INFO_KIND = nlpacket.Link.IFLA_INFO_KIND
    IFLA_INFO_DATA = nlpacket.Link.IFLA_INFO_DATA
    IFLA_VXLAN_GROUP = nlpacket.Link.IFLA_VXLAN_GROUP
    IFLA_VXLAN_ID = nlpacket.Link.IFLA_VXLAN_ID
    IFLA_VXLAN_LOCAL = nlpacket.Link.IFLA_VXLAN_LOCAL
    IFLA_VXLAN_PORT = nlpacket.Link.IFLA_VXLAN_PORT
    NDA_DST = nlpacket.Neighbor.NDA_DST
    NDA_LLADDR = nlpacket.Neighbor.NDA_LLADDR
    NDA_PROBES = nlpacket.Neighbor.NDA_PROBES
    # This should eventually make its way into nlmananger
    NDA_VLAN = NDA_PROBES + 1
    NDA_PORT = NDA_PROBES + 2
    NDA_VNI = NDA_PROBES + 3
    NDA_IFINDEX = NDA_PROBES + 4
    NDA_MASTER = NDA_PROBES + 5
    RTA_PREFSRC = nlpacket.Route.RTA_PREFSRC
    RTA_DST = nlpacket.Route.RTA_DST
    RTN_LOCAL = nlpacket.Route.RTN_LOCAL
    VXLAN_ID = nlpacket.Link.IFLA_VXLAN_ID
    RTA_TABLE = nlpacket.Route.RTA_TABLE
    NUD_PERMANENT = nlpacket.Neighbor.NUD_PERMANENT
    NUD_STALE = nlpacket.Neighbor.NUD_STALE
    NUD_REACHABLE = nlpacket.Neighbor.NUD_REACHABLE
    NUD_FAILED = nlpacket.Neighbor.NUD_FAILED
    NUD_INCOMPLETE = nlpacket.Neighbor.NUD_INCOMPLETE
    NUD_DELAY = nlpacket.Neighbor.NUD_DELAY

    def __init__(self, conf, logger, process_cb, pool=None):
        # debug is a reloadable option; so we need to store a reference to
        # the configuration object and inspect the debug value at runtime
        self.__conf = conf
        self.__intfevent = None
        self.__intfqueue = None
        self.__logger = logger
        self.__unacknowledged = None
        # PID_MAX_LIMIT is 2^22 allowing 1024 sockets per-pid. We
        # start with 1 in the upper space (top 10 bits) instead of
        # 0 to avoid conflicts with netlink_autobind which always
        # attempts to bind with the pid (and on failure with
        # negative values -4097, -4098, -4099 etc.)
        self.__pid = os.getpid() | (1 << 22)
        self.__pool = pool or eventlet.GreenPool()
        self.__process_cbs = process_cb
        self.__running = set()
        self.__tsocketpool = eventlet.pools.TokenPool(max_size=1)
        self.__seqno = None
        self.dispatcher_gt = None
        self.stats = NetlinkStat()
        self.socket = None
        self.reset()

    def __dispatcher(self):
        """ Main thread that drains interface queues by invoking handler
        methods based on the message type.
        Netlink messages for different interfaces can be served concurrently;
        however, strict ordering must be maintained between messages
        for the same interface. In order to facilitate this, a queue is
        allocated on a per interface basis, and the dispatcher uses a
        modified FCFS algorithm to schedule threads for messages in these
        queues.
        Dispatch algorithm:
        The dispatcher monitors the intfevent queue for interface events. On
        receiving a new event, it checks to see if another thread is
        serving the same interface. If not, it spawns one to handle the first
        message in the interface's queue. When the new thread is done, it
        notifies the dispatcher by placing the interface's index on the
        "intfevent" queue.
        """
        while True:
            ifindex = self.__intfevent.get()
            if ifindex in self.__intfqueue and ifindex not in self.__running:
                try:
                    msg_type, info = self.__intfqueue[ifindex].get_nowait()
                except eventlet.queue.Empty:
                    self.__intfqueue.pop(ifindex)
                else:
                    self.__running.add(ifindex)
                    green_thread = self.__pool.spawn(
                        self.__process_cbs[msg_type],
                        info
                    )
                    green_thread.link(self.__stop_checker)

    @staticmethod
    def __get_value(attrs, key):
        """ Returns the value associated with a key in attrs.
        """
        return next((val for attr, val in attrs or [] if attr == key), None)

    def __stop_checker(self, green_thread):
        """ Propagates exceptions to the dispatcher green thread.
        """
        ifindex = None
        try:
            ifindex = green_thread.wait()
        except greenlet.GreenletExit:  # pylint: disable=no-member
            pass
        except Exception:  # pylint: disable=broad-except
            eventlet.kill(self.dispatcher_gt, *sys.exc_info())
        self.__running.remove(ifindex)
        self.__intfevent.put(ifindex)

    def __tx_nlpacket(self, pkt):
        """TX the message and wait for an ack
        """
        # NetlinkListener looks at the manager's target_seq and target_pid
        # to know when we've RXed the ack that we want
        identifier = (pkt.seq, pkt.pid)
        self.__unacknowledged.add(identifier)
        interval = 1
        while identifier in self.__unacknowledged:
            with self.__tsocketpool.item() as _:
                try:
                    self.socket.sendall(pkt.message)
                except Exception:  # pylint: disable=broad-except
                    self.__logger.exception('Failed to send netlink message')
            eventlet.sleep(interval)
            interval *= 2
        return True

    def bind(self):
        """ Binds the netlink socket and initializes data structures used for
        communication between the dispatcher and the server.
        """
        with self.__tsocketpool.item() as _:
            if self.socket is not None:
                try:
                    self.socket.close()
                except socket.error as ex:
                    # Ignore the error as we will try to rebind.
                    self.__logger.warning('socket close failed %s', ex)
            try:
                # pylint: disable=no-member
                self.socket = socket.socket(socket.AF_NETLINK,
                                            socket.SOCK_RAW,
                                            self.NETLINK_ROUTE)
                # Set rcv. buffer size to 30M (higher than the rmem_max of 8M).
                self.socket.setsockopt(socket.SOL_SOCKET,
                                       self.__SO_RCVBUFFORCE,
                                       self.__BUF_SIZE)
            except socket.error as ex:
                self.__logger.warning('socket open failed %s', ex)
                raise RuntimeError('open: socket err: %s' % ex)
            # Open a socket for receiving netlink msgs.
            try:
                self.socket.bind((self.__pid, Netlink.GROUPS))
            except socket.error as ex:
                self.__logger.warning('socket bind failed %s', ex)
                raise RuntimeError('bind: socket err: %s' % ex)

    def get_all_addresses(self):
        family = socket.AF_UNSPEC
        pkt = nlpacket.Address(RTM_GETADDR, self.__conf.debug, self.__logger)
        pkt.flags = NLM_F_REQUEST | NLM_F_DUMP
        pkt.body = struct.pack('Bxxxi', family, 0)
        pkt.build_message(self.__seqno.next(), self.__pid)
        return self.__tx_nlpacket(pkt)

    def get_all_links(self):
        family = socket.AF_UNSPEC
        pkt = nlpacket.Link(RTM_GETLINK, self.__conf.debug, self.__logger)
        pkt.flags = NLM_F_REQUEST | NLM_F_DUMP
        pkt.body = struct.pack('Bxxxiii', family, 0, 0, 0)
        pkt.build_message(self.__seqno.next(), self.__pid)
        return self.__tx_nlpacket(pkt)

    def get_all_neighbors(self):
        family = socket.AF_UNSPEC
        pkt = nlpacket.Neighbor(RTM_GETNEIGH, self.__conf.debug, self.__logger)
        pkt.flags = NLM_F_REQUEST | NLM_F_DUMP
        pkt.body = struct.pack('Bxxxii', family, 0, 0)
        pkt.build_message(self.__seqno.next(), self.__pid)
        return self.__tx_nlpacket(pkt)

    def get_all_macs(self):
        family = socket.AF_BRIDGE
        pkt = nlpacket.Neighbor(RTM_GETNEIGH, self.__conf.debug, self.__logger)
        pkt.flags = NLM_F_REQUEST | NLM_F_DUMP
        pkt.body = struct.pack('Bxxxii', family, 0, 0)
        pkt.build_message(self.__seqno.next(), self.__pid)
        return self.__tx_nlpacket(pkt)

    def get_all_routes(self):
        family = socket.AF_UNSPEC
        pkt = nlpacket.Route(RTM_GETROUTE, self.__conf.debug, self.__logger)
        pkt.flags = NLM_F_REQUEST | NLM_F_DUMP
        pkt.body = struct.pack('Bxxxii', family, 0, 0)
        pkt.build_message(self.__seqno.next(), self.__pid)
        return self.__tx_nlpacket(pkt)

    def handle_netlink_msg(self, pkt, _):
        """ Parses an incoming RTNL message and places the result on a queue
        identified by the interface's index. Notifies the dispatcher by
        placing the interface's index on the "intfevent" queue.
        :param pkt: netlink message
        """
        offset = 0
        while offset < len(pkt):
            msg_len, msg_type, flags, seq, pid = (
                struct.unpack_from(self.__NLMSG_FMT,
                                   pkt,
                                   offset)
            )
            # 99% of the time when we see an ERROR the error code is zero
            # which means ACK
            possible_ack = False
            if msg_type == nlpacket.NLMSG_DONE:
                possible_ack = True
            elif msg_type == nlpacket.NLMSG_ERROR:
                error_code = int(
                    struct.unpack_from('>H', pkt, offset + self.__NLMSG_LEN)[0]
                )
                if error_code:
                    self.__logger.info("RXed NLMSG_ERROR code %d", error_code)
                else:
                    possible_ack = True
            if possible_ack:
                self.__unacknowledged -= {(seq, pid)}
            if msg_type in self.__process_cbs:
                if msg_type in [RTM_NEWADDR, RTM_DELADDR]:
                    msg = nlpacket.Address(msg_type, self.__conf.debug,
                                           self.__logger)
                elif msg_type in [RTM_NEWLINK, RTM_DELLINK]:
                    msg = nlpacket.Link(msg_type, self.__conf.debug,
                                        self.__logger)
                elif msg_type in [RTM_NEWNEIGH, RTM_DELNEIGH]:
                    msg = nlpacket.Neighbor(msg_type, self.__conf.debug,
                                            self.__logger)
                elif msg_type in [RTM_NEWROUTE, RTM_DELROUTE]:
                    msg = nlpacket.Route(msg_type, self.__conf.debug,
                                         self.__logger)
                try:
                    msg.decode_packet(msg_len, flags, seq, pid,
                                      pkt[offset:offset + msg_len])
                except Exception:  # pylint: disable=broad-except
                    if self.__conf.debug:
                        msg.dump()
                    self.__logger.error('Error decoding netlink msg.')
                else:
                    info = None
                    if msg_type in self.stats.ALL:
                        self.stats.increment(msg_type, 1)
                    if msg_type in [RTM_NEWADDR, RTM_DELADDR]:
                        info = Address(
                            msg.ifindex,
                            str(msg.get_attribute_value(Netlink.IFA_ADDRESS)),
                            str(msg.prefixlen),
                            msg.family
                        )
                    elif msg_type in [RTM_NEWLINK, RTM_DELLINK]:
                        ifindex = msg.ifindex
                        ifname = msg.get_attribute_value(Netlink.IFLA_IFNAME)
                        mac_address = (
                            msg.get_attribute_value(Netlink.IFLA_ADDRESS)
                        )
                        admin_state = (
                            InterfaceState.UP if msg.is_up() else
                            InterfaceState.DOWN
                        )

                        flags = msg.get_flags_string()
                        if flags and 'IFF_RUNNING' in flags:
                            oper_state = InterfaceState.UP
                        else:
                            oper_state = InterfaceState.DOWN

                        mtu = msg.get_attribute_value(Netlink.IFLA_MTU)
                        linkinfo = (
                            msg.attributes.get(Netlink.IFLA_LINKINFO, None)
                        )
                        if msg.family == socket.AF_BRIDGE:
                            kind = 'ignore'  # AF_BRIDGE doesn't provide kind
                        elif linkinfo is not None:
                            kind = linkinfo.value.get(Netlink.IFLA_INFO_KIND,
                                                      None)
                        else:
                            kind = None

                        master_ifindex = (
                            msg.get_attribute_value(Netlink.IFLA_MASTER)
                        )

                        if (kind == LinkType.VXLAN and
                            Netlink.IFLA_INFO_DATA in linkinfo.value):
                            linkinfo_attrs = (
                                linkinfo.value[Netlink.IFLA_INFO_DATA]
                            )
                            vni = int(linkinfo_attrs[Netlink.IFLA_VXLAN_ID])
                            localip = str(
                                linkinfo_attrs[Netlink.IFLA_VXLAN_LOCAL]
                            )
                            dstport = (
                                linkinfo_attrs.get(Netlink.IFLA_VXLAN_PORT,
                                                   None)
                            )
                            info = Link(msg.family, ifindex, master_ifindex,
                                        ifname, admin_state, oper_state,
                                        mac_address, kind, mtu,
                                        dstport, localip, vni)
                        else:
                            info = Link(msg.family, ifindex, master_ifindex,
                                        ifname, admin_state, oper_state,
                                        mac_address, kind=kind, mtu=mtu)
                    elif msg_type in [RTM_NEWNEIGH, RTM_DELNEIGH]:
                        if ((msg.state & Netlink.NUD_REACHABLE) or
                                (msg.state & Netlink.NUD_STALE) or
                                (msg.state & Netlink.NUD_PERMANENT)):
                            state = NeighborState.UPDATE
                        elif ((msg.state & Netlink.NUD_DELAY) or
                              (msg.state & Netlink.NUD_FAILED) or
                              (msg.state & Netlink.NUD_INCOMPLETE)):
                            state = NeighborState.DELETE
                        else:
                            state = NeighborState.IGNORE

                        info = Neighbor(
                            msg.ifindex,
                            msg.get_attribute_value(Netlink.NDA_DST),
                            msg.get_attribute_value(Netlink.NDA_LLADDR),
                            msg.get_attribute_value(Netlink.NDA_VLAN),
                            msg.get_attribute_value(Netlink.NDA_PORT),
                            state,
                            msg.family
                        )
                    elif msg_type in [RTM_NEWROUTE, RTM_DELROUTE]:
                        protocol = msg.get_protocol_string()
                        info = Route(
                            msg.route_type == Netlink.RTN_LOCAL,
                            msg.get_prefix_string(),
                            Route.get_nexthops(msg),
                            protocol,
                            str(msg.get_attribute_value(
                                Netlink.RTA_PREFSRC)),
                            msg.family,
                            msg.table_id
                        )
                    if info is not None:
                        self.__intfqueue[info.ifindex].put((msg_type, info))
                        self.__intfevent.put(info.ifindex)
            offset += msg_len

    def reset(self):
        self.__seqno = iter(xrange(10000))
        self.__unacknowledged = set()
        self.__intfqueue = collections.defaultdict(eventlet.Queue)
        while self.__running:
            eventlet.sleep(1)
        self.__intfevent = eventlet.Queue()
        if self.dispatcher_gt is not None:
            eventlet.kill(self.dispatcher_gt)
        self.stats.reset()

    def run(self):
        """ Spawns and returns the dispatcher thread.
        """
        self.dispatcher_gt = self.__pool.spawn(self.__dispatcher)
        return self.dispatcher_gt
