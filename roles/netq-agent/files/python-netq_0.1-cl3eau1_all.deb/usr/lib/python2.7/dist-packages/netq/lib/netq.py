# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

import calendar
import json
import re
import socket
import subprocess
import sys
import time
from datetime import datetime, timedelta

import ipaddr
from tabulate import tabulate

from netq.common import config, utils
from netq.common.enums import (
    BgColors,
    Heartbeat,
    DefaultPaths,
    LinkType
)
from netq.lib import parsers
from netq.orm import HOSTNAME
from netq.orm import redisdb, restapi
from netq.orm.memdb.models import (
    Lldp
)
from netq.orm.redisdb.models import (
    Address,
    BgpSession,
    ClagSession,
    Command,
    Counter,
    CounterHistory,
    Link,
    MacFdb,
    MstpInfo,
    Neighbor,
    Node,
    Route,
    Services
)
from netq.orm.redisdb.query import RedisQuery


class AgentHealth(object):

    ROTTEN = 'Rotten'
    STALE = 'Stale'
    FRESH = 'Fresh'

    def __init__(self):
        raise NotImplementedError


class MstpStatus(object):
    """A class just to keep the status straight
    """
    BPDUGUARD_ERR = 1
    DISPUTED = 2
    BA_INCONSISTENT = 3
    TCN = 4


def get_hostname():
    # deal with -s <server-ip>|<hostname> view [around <time>] <host> <cmd>
    if sys.argv[1] == 'server':
        offset = 2
    else:
        offset = 0
    if sys.argv[offset + 1] == 'view':
        if sys.argv[offset + 2] == 'around':
            hostname = sys.argv[offset + 4]
        else:
            hostname = sys.argv[offset + 2]
    elif sys.argv[offset + 2] in ['interfaces', 'lldp', 'macs', 'addresses']:
        hostname = sys.argv[offset + 3]
    elif (sys.argv[offset + 2] in ['ip', 'ipv6'] and
          sys.argv[offset + 3] in ['neighbors', 'routes']):
        hostname = sys.argv[offset + 4]
    else:
        # all other commands have the hostname just before the
        # current arg
        hostname = sys.argv[-2]
    return hostname


class NetQException(Exception):
    def __init__(self, *args, **kwargs):
        super(NetQException, self).__init__(*args, **kwargs)


class NetQ(object):
    __INTF_REGEX = re.compile(
        r'^\d+: (?P<dev_name>\S+):\s+'
        r'<.*(?P<slave>SLAVE).*>'
        r'(?=.*inet (?P<ipv4>\S+) scope (?P<scopev4>\S+))'
        r'(?=.*inet6 (?P<ipv6>\S+) scope (?P<scopev6>\S+))'
        r'(?=.*master (?P<master>\S+))'
        r'(?=.*link/ether (?P<mac>\S+))'
    )

    __IP_ADDR_REGEX = re.compile(
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?:/\d+)?'
    )

    __TIME_REGEX = re.compile(
        r'(?:(?:(?P<days>[\d|.]+)d)|'
        r'(?:(?P<hours>[\d|.]+)h)|'
        r'(?:(?P<minutes>[\d|.]+)m)|'
        r'(?:(?P<seconds>[\d|.]+)s))'
    )

    __TRACEROUTE_REGEX = r'\s*(?P<idx>\d+).*'

    ADDR_KEY = 'addr'
    BGP_SUMMARY_KEY = 'bgp-summary-json'
    BGP_NEIGHBOR_KEY = 'bgp-neighbors'
    CLAGCTL_JSON_KEY = 'clagctl-json'
    LLDP_NEIGHBOR_KEY = 'lldp-neighbor-json'
    UPTIME_KEY = 'uptime'
    MEMINFO_KEY = 'meminfo'

    def __init__(self, server_addr, start_time, end_time):
        self.__node_lst = None
        self.failed_node_lst = {}

        self.__server_addr = (
            self.__get_server_address(server_addr) or
            self.__get_config_server_addr()
        )

        self.__start_time = self.__get_time(start_time)
        self.__end_time = self.__get_time(end_time)
        if (self.__start_time is not None and self.__end_time is not None and
                self.__start_time <= self.__end_time):
            raise RuntimeError('Start time %s should be less than end '
                               'time %s' % (start_time, end_time))
        if self.__server_addr is not None and 'http' in self.__server_addr:
            restapi.set_connection_settings(self.__server_addr)
        else:
            redisdb.set_connection_settings(self.__server_addr)

    def __build_failed_node_lst(self):
        """Build list of nodes that have rotten state
        """
        for node in self.node_lst:
            last_beat = (datetime.utcnow() -
                         datetime.utcfromtimestamp(node.timestamp))
            if last_beat.total_seconds() > Heartbeat.HEARTBEAT_DEATH:
                self.failed_node_lst[node.hostname] = 1000*node.timestamp
            elif node.hostname in self.failed_node_lst:
                self.failed_node_lst.pop(node.hostname, None)

    def __build_lldp_info(self, hostname=None):
        self.__build_failed_node_lst()

        if hostname is not None:
            nodes = sorted(Node.query.filter(hostname=hostname))
        else:
            nodes = self.node_lst

        for node in nodes:
            cmd = Command.query.get(timestamp=self.__start_time,
                                    key=NetQ.LLDP_NEIGHBOR_KEY,
                                    hostname=node.hostname)
            if cmd is not None:
                try:
                    parsers.build_lldp_summary(node.hostname, cmd.timestamp,
                                               cmd.output)
                except Exception:  # pylint: disable=broad-except
                    continue

    @staticmethod
    def __get_config_server_addr():
        try:
            conf = config.Config(DefaultPaths.CONF_FILE)
            if conf.server:
                return conf.server
        except Exception:  # pylint: disable=broad-except
            pass
        try:
            with open(DefaultPaths.DBCONFIG_RUNNING, 'r') as fd:
                base_config_json = json.load(fd)
                if 'server' in base_config_json:
                    return (
                        str(ipaddr.IPv4Network(base_config_json['server']).ip)
                    )
        except Exception:  # pylint: disable=broad-except
            raise RuntimeError('Please specify IP address of DB server')

    @staticmethod
    def __get_server_address(server_addr):
        try:
            return str(ipaddr.IPAddress(server_addr))
        except Exception:  # pylint: disable=broad-except
            try:
                return socket.gethostbyname(server_addr)
            except Exception:  # pylint: disable=broad-except
                return server_addr

    def __get_time(self, start_time):
        if start_time is None:
            return start_time
        match = self.__TIME_REGEX.match(start_time)
        if match is not None:
            groupdict = match.groupdict()
            return calendar.timegm(
                (
                    datetime.utcnow() -
                    timedelta(
                        days=float(groupdict['days'] or 0),
                        hours=float(groupdict['hours'] or 0),
                        minutes=float(groupdict['minutes'] or 0),
                        seconds=float(groupdict['seconds'] or 0)
                    )
                ).utctimetuple()
            )
        try:
            return calendar.timegm(
                datetime.strptime(start_time,
                                  '%Y-%m-%dT%H:%M:%S.%fZ').utctimetuple()
            )
        except Exception:  # pylint: disable=broad-except
            try:
                return calendar.timegm(
                    datetime.strptime(start_time, '%Y-%m-%d').utctimetuple()
                )
            except Exception:  # pylint: disable=broad-except
                try:
                    datetime.utcfromtimestamp(start_time)
                    return start_time
                except Exception:  # pylint: disable=broad-except
                    raise RuntimeError('Time format %s not understood' %
                                       start_time)

    def __top_talkers(self, count, keys):
        output = {}
        prefixes = ['if_', 'if_drop_', 'if_err_']
        for key, prefix in zip(keys, prefixes):
            if self.__start_time is not None:
                qry = CounterHistory.query.filter(timestamp=self.__start_time,
                                                  key_type=key)
                results = []
                if qry is not None:
                    data = next(qry, None)
                    if data is not None:
                        idx = 0
                        for ele in data.data:
                            scorefmt = Counter.score_fmt(key_type=key)
                            score = scorefmt.from_redis(ele.get(scorefmt.name))
                            obj = Counter.val_to_obj(json.dumps(ele))
                            obj = Counter.score_to_obj(score, key_type=key,
                                                       obj=obj)
                            obj.timestamp = data.timestamp
                            results.append(obj)
                            idx += 1
                            if idx == count:
                                break
            else:
                results = list(Counter.query.range(start=0,
                                                   end=count,
                                                   reverse=True,
                                                   key_type=key,
                                                   active=True,
                                                   first=False))
            output[prefix + 'bps'] = []
            output[prefix + 'ts'] = None
            if results:
                score_fmt = Counter.score_fmt(key_type=key)
                output[prefix + 'bps'] = [
                    (ele.hostname, ele.ifname, getattr(ele, score_fmt.name))
                    for ele in results if getattr(ele, score_fmt.name)
                ]
                if output[prefix + 'bps']:
                    output[prefix + 'ts'] = results[0].timestamp
        return output

    def __get_lldp_nbr_entry(self, hostname, ifname):
        """
        Retrieve the LLDP neighbor entry for the specified interface.
        The specified interface can be a bond as well
        """
        nbr = None
        link = Link.query.get(timestamp=self.__start_time,
                              hostname=hostname, ifname=ifname)
        if not link:
            return nbr

        if link.kind == 'bond' and link.slaves:
            for slave in link.slaves:
                slave = slave.encode('ascii', 'ignore')
                nbr = Lldp.query.get(timestamp=self.__start_time,
                                     hostname=hostname, ifname=slave)
                if nbr:
                    break
        else:
            nbr = Lldp.query.get(timestamp=self.__start_time,
                                 hostname=hostname, ifname=ifname)

        return nbr

    def __compare_vlans(self, str1, str2):
        """Compare two VLAN list strings and return 0 if equal, else 1
        """
        list1 = []
        list2 = []

        for word in str1.split():
            if '-' in word:
                svlan, evlan = word.split('-')
                list1 += range(int(svlan), int(evlan) + 1)
            else:
                list1 += [int(word)]

        for word in str2.split():
            if '-' in word:
                svlan, evlan = word.split('-')
                list2 += range(int(svlan), int(evlan) + 1)
            else:
                list2 += [int(word)]

        return sorted(list1) == sorted(list2)

    def __get_stp_root(self, root_brmac):
        """Given a root bridge ID, get the root switch name
        """
        root_swname = None
        entries = self.show_macvlan(root_brmac, '*', '*', '*', True)
        try:
            entry = entries.next()
            root_swname = entry[0][2]
        except StopIteration:
            # When doing CLAG, the bridge ID is the CLAG sysmac
            entry = ClagSession.query.get(timestamp=self.__start_time,
                                          clag_sysmac=root_brmac)
            if entry:
                root_swname = entry.hostname

        return root_swname

    def __get_parent_bond(self, hostname, slave_if):
        """Get parent bond interface if any
        """
        for port in Link.query.filter(timestamp=self.__start_time,
                                      hostname=hostname, kind=LinkType.BOND):
            if slave_if in port.slaves:
                return port.ifname

        return None

    def __get_clag_peer_hostname(self, this_host, clag_peer_if):

        peername = '*'
        if '.' in clag_peer_if:
            peer_if = clag_peer_if.split('.')[0]
        else:
            peer_if = clag_peer_if
        lldp_peer = self.__get_lldp_nbr_entry(this_host, peer_if)
        if lldp_peer:
            peername = lldp_peer.peer_hostname

        return peername

    def __get_link_details(self, link):
        """Get link details
        """
        default_output_types = [LinkType.SWP, LinkType.ETH, LinkType.LOOPBACK,
                                LinkType.VLAN]
        details = ''
        if any(link.kind == i for i in default_output_types):
            lldp_string = ''
            lldp_peer = Lldp.query.get(self.__start_time,
                                       hostname=link.hostname,
                                       ifname=link.ifname)

            if lldp_peer is not None:
                lldp_string = '%s:%s' % (lldp_peer.peer_hostname,
                                         lldp_peer.peer_ifname)
                details = 'LLDP: %s, MTU: %s' % (lldp_string, link.mtu)
            else:
                details = 'MTU:% s' % (link.mtu)
        elif link.kind == LinkType.BOND:
            details += ''
            for slave in link.slaves:
                slave = slave.encode('ascii', 'ignore')
                lldp_peer = Lldp.query.get(self.__start_time,
                                           hostname=link.hostname,
                                           ifname=slave)
                if lldp_peer is not None:
                    lldp_string = '%s:%s' % (lldp_peer.peer_hostname,
                                             lldp_peer.peer_ifname)
                else:
                    lldp_string = ''

                details += 'Slave: %s(%s), ' % (slave, lldp_string)
            details += ('VLANs: %s, PVID: %s, Master: %s, MTU: %s' %
                        (link.vlans, link.access_vlan, link.master,
                         link.mtu))

        elif link.kind == LinkType.BRIDGE:
            mstp_session = MstpInfo.query.get(timestamp=self.__start_time,
                                              hostname=link.hostname,
                                              bridge_name=link.ifname)
            if mstp_session:
                rootbr = self.__get_stp_root(
                    mstp_session.root_bridge.split('.')[2]
                )
                if not rootbr:
                    rootbr = 'No Info'
                if rootbr != link.hostname:
                    rootport = mstp_session.root_port_name
                else:
                    rootport = 'N/A'
            else:
                rootbr = 'No Info'
                rootport = 'No Info'
            root_mbrs = ','.join([i.encode('ascii', 'ignore')
                                  for i in link.slaves])
            details = (
                'Members: %s, Root Bridge: %s, Root port %s, MTU: %d' %
                (root_mbrs, rootbr, rootport, link.mtu)
            )
        elif link.kind == LinkType.VXLAN:
            details = ('VNI: %s, PVID: %s, Master: %s, VTEP: %s, MTU: %s' %
                       (link.vni, link.access_vlan, link.master,
                        link.localip, link.mtu))
        elif link.kind == LinkType.MACVLAN:
            details = 'MAC: %s, Mode: Private' % link.mac_address
        return details

    def __process_show_fdb_entry(self, macfdb, nexthop, origin, known_nodes):
        """Return the appropriate values we need for displaying MAC entries"""

        if macfdb.mac_address == '00:00:00:00:00:00':
            return None

        if nexthop != '*' and macfdb.nexthop != nexthop:
            return None

        # If peer is unknwon or not in our DB, we mark that too as the
        # origin
        if macfdb.dst:
            vtep_addr = Address.query.get(timestamp=self.__start_time,
                                          prefix=macfdb.dst)
            if vtep_addr:
                nh = '%s:%s' % (macfdb.nexthop, vtep_addr.hostname)
            else:
                nh = '%s:%s' % (macfdb.nexthop, macfdb.dst)
            nbr = None
        else:
            nbr = self.__get_lldp_nbr_entry(macfdb.hostname, macfdb.nexthop)
            nh = macfdb.nexthop
            if nbr is None or nbr.peer_hostname not in known_nodes:
                macfdb.origin = True

        if origin != '*' and origin != macfdb.origin:
            return None

        if macfdb.vlan == 0:
            vlan = 'Intf'
        elif macfdb.vlan == -1:
            vlan = '??'
        else:
            vlan = macfdb.vlan
        return([macfdb.mac_address, vlan, macfdb.hostname,
                nh, macfdb.origin, macfdb.timestamp])

    def path_trace_mac(self, mac, vlan, start):
        """
        """
        output = []
        self.__build_lldp_info()
        self.__build_failed_node_lst()

        if not start:
            start = HOSTNAME

        for entry in MacFdb.query.filter(timestamp=self.__start_time,
                                         hostname=start,
                                         mac_address=mac,
                                         vlan=vlan):
            output.append('%s:%s' % (entry.hostname, entry.nexthop))
            nexthop = entry.nexthop
            link = Link.query.get(timestamp=self.__start_time,
                                  hostname=entry.hostname,
                                  ifname=nexthop)

            if link and link.kind == LinkType.VXLAN:
                if not entry.dst:
                    # Sometimes entries get created before we've had a
                    # chance to get the remote dst port and correct vlan
                    ventry = MacFdb.query.get(timestamp=self.__start_time,
                                              hostname=start,
                                              mac_address=mac,
                                              vlan=0)
                    if ventry:
                        entry.dst = ventry.dst

            if link:
                if link.kind == LinkType.BOND:
                    for slave in link.slaves:
                        nbrs = Lldp.query.filter(timestamp=self.__start_time,
                                                 hostname=entry.hostname,
                                                 ifname=slave)
                        for nbr in nbrs:
                            peer_nif = '%s:%s' % (entry.hostname, slave)
                            sout = self.path_trace_mac(mac, vlan,
                                                       nbr.peer_hostname)
                            if sout == '':
                                output.append([peer_nif,
                                               '%s:%s' % (nbr.peer_hostname,
                                                          nbr.peer_ifname)])
                            else:
                                output.append([peer_nif, sout])
                            break
                        else:
                            output.append([slave, ''])
                elif link.kind == LinkType.VXLAN and entry.dst:
                    remotenodes = Address.query.filter(
                        timestamp=self.__start_time,
                        prefix=entry.dst
                    )
                    for rnode in remotenodes:
                        vxlink = Link.query.get(timestamp=self.__start_time,
                                                hostname=rnode.hostname,
                                                kind=LinkType.VXLAN,
                                                vni=link.vni)
                        if vxlink:
                            output.append([
                                '%s:%s' % (vxlink.hostname,
                                           vxlink.ifname),
                                self.path_trace_mac(mac, vlan, vxlink.hostname)
                            ])
                        else:
                            output.append([entry.nexthop, ''])
                else:
                    nbrs = Lldp.query.filter(timestamp=self.__start_time,
                                             hostname=entry.hostname,
                                             ifname=entry.nexthop)
                    for nbr in nbrs:
                        peer_nif = '%s:%s' % (entry.hostname, entry.nexthop)
                        sout = self.path_trace_mac(mac, vlan,
                                                   nbr.peer_hostname)
                        if sout == '':
                            output.append([peer_nif,
                                           '%s:%s' % (nbr.peer_hostname,
                                                      nbr.peer_ifname)])
                        else:
                            output.append([peer_nif,
                                           self.path_trace_mac(
                                               mac, vlan,
                                               nbr.peer_hostname)])
                        break
                    else:
                        output.append([entry.nexthop, ''])

        if not output:
            return ''

        return output

    def path_trace_route(self, ip, start):
        """
        """
        output = []
        self.__build_lldp_info()
        self.__build_failed_node_lst()
        visited_nodes = []

        if not start:
            start = HOSTNAME

        is_ipv6 = ':' in ip

        subtree = []
        for entry in Route.query.lpm(ip, [start],
                                     timestamp=self.__start_time,
                                     is_ipv6=is_ipv6):
            nhlen = len(entry.nexthops)
            if not nhlen:
                if not subtree:
                    # We've reached the end of the line
                    output = [start]
                else:
                    output.append([start, subtree])

                return output

            for nhop in entry.nexthops:
                nexthop = nhop[1].encode('ascii', 'ignore')
                link = Link.query.get(timestamp=self.__start_time,
                                      hostname=entry.hostname,
                                      ifname=nexthop)
                if link:
                    if link.kind == LinkType.BOND:
                        for slave in link.slaves:
                            nbrs = Lldp.query.filter(
                                timestamp=self.__start_time,
                                hostname=entry.hostname,
                                ifname=slave
                            )
                            peer_nif = 'Intf(%s)' % slave
                            for nbr in nbrs:
                                if nbr.peer_hostname in visited_nodes:
                                    sys.stderr.write(
                                        utils.color_wrap(
                                            BgColors.RED,
                                            'Detected Routing Loop. Node  %s '
                                            '(now via %s) visited twice.\n' %
                                            (nbr.peer_hostname, visited_nodes)
                                        )
                                    )
                                    subtree.append(['Intf(%s)' % nbr.ifname,
                                                    utils.color_wrap(
                                                        BgColors.RED, 'Loop')]
                                    )
                                    output.append([start, subtree])
                                    return output

                                visited_nodes.append(nbr.peer_hostname)
                                subtree.append(
                                    [peer_nif,
                                     self.path_trace_route(ip,
                                                           nbr.peer_hostname)
                                    ]
                                )
                                break
                            else:
                                subtree.append([peer_nif, ''])
                    else:
                        nbrs = Lldp.query.filter(timestamp=self.__start_time,
                                                 hostname=entry.hostname,
                                                 ifname=nexthop)
                        peer_nif = 'Intf(%s)' % nexthop
                        for nbr in nbrs:
                            if nbr.peer_hostname in visited_nodes:
                                sys.stderr.write(
                                    utils.color_wrap(
                                        BgColors.RED,
                                        'Detected Routing Loop. Node %s (now '
                                        'via %s) visited twice.\n'
                                        % (nbr.peer_hostname, visited_nodes)
                                    )
                                )
                                subtree.append(['Intf(%s)' % nbr.ifname,
                                                utils.color_wrap(
                                                    BgColors.RED, 'Loop'
                                                )]
                                )
                                output.append([start, subtree])
                                return output

                            visited_nodes.append(nbr.peer_hostname)
                            subtree.append(
                                [peer_nif,
                                 self.path_trace_route(ip,
                                                       nbr.peer_hostname)
                                ]
                            )
                            break
                        else:
                            subtree.append([peer_nif, ''])
                            break
                else:
                    subtree.append(['Intf(%s)' % nexthop, ''])

        if subtree:
            output.append([start, subtree])
        else:
            output.append([start, ''])

        return output

    def build_stp_topo(self, node_at, brname, visit_peer, top, visited_nodes):
        """Generate the active spanning tree topology
        """

        stpmap = []
        peername = None

        # Lets get the peer node name if there's one
        entry = ClagSession.query.get(timestamp=self.__start_time,
                                      hostname=node_at)
        if entry:
            nbr = self.__get_lldp_nbr_entry(node_at,
                                            entry.peer_if.split('.')[0])
            if nbr:
                peername = nbr.peer_hostname

        br_mstp_info = MstpInfo.query.get(timestamp=self.__start_time,
                                          hostname=node_at, bridge_name=brname)
        if not br_mstp_info:
            # This can happen if the agent is not running on the root bridge
            return ['No info', '']

        subtree = []
        for port in br_mstp_info.ports.keys():
            if br_mstp_info.ports[port]['role'] == 'Designated':
                if br_mstp_info.ports[port]['clagIsl']:
                    port = port.encode('ascii', 'ignore')
                    nbr = self.__get_lldp_nbr_entry(node_at, port)
                    if nbr:
                        subtree.append([utils.color_wrap(BgColors.YELLOW,
                                                         'ClagIsl(%s)' % port),
                                        nbr.peer_hostname])
                    continue

                port = port.encode('ascii', 'ignore')
                nbr = self.__get_lldp_nbr_entry(node_at, port)
                if nbr:
                    # We have to verify the peer is also in Fwd state on this
                    # port
                    peer_mstp_info = MstpInfo.query.get(
                        timestamp=self.__start_time, hostname=nbr.peer_hostname,
                        bridge_name=brname
                    )
                    if peer_mstp_info:
                        if nbr.peer_ifname in peer_mstp_info.ports:
                            mstp_pinfo = peer_mstp_info.ports[nbr.peer_ifname]
                            pbif = nbr.peer_ifname
                        else:
                            # This might be part of a bond, and so get parent
                            pbif = self.__get_parent_bond(nbr.peer_hostname,
                                                          nbr.peer_ifname)
                            if pbif and pbif in peer_mstp_info.ports:
                                mstp_pinfo = peer_mstp_info.ports[pbif]
                            else:
                                continue

                        if mstp_pinfo['state'] != 'forwarding':
                            subtree.append(
                                [utils.color_wrap(BgColors.GRAY,
                                                  'Blocked(%s)' % port),
                                 nbr.peer_hostname]
                            )
                            continue

                        if nbr.peer_hostname in visited_nodes:
                            sys.stderr.write(
                                utils.color_wrap(BgColors.RED,
                                                 'Detected STP Loop. Node %s'
                                                 '(now via %s) visited twice.\n'
                                                 % (nbr.peer_hostname, pbif)
                                                )
                            )
                            subtree.append(['Intf(%s)' % port,
                                            utils.color_wrap(BgColors.RED,
                                                             'Loop')])
                            stpmap.append([node_at, subtree])
                            return stpmap

                        visited_nodes.append(nbr.peer_hostname)
                        subtree.append(['Intf(%s)' % port,
                                        self.build_stp_topo(nbr.peer_hostname,
                                                            brname,
                                                            True, False,
                                                            visited_nodes)])
                    else:
                        port = port.encode('ascii', 'ignore')
                        nbr = self.__get_lldp_nbr_entry(node_at, port)
                        if nbr:
                            if port in br_mstp_info.edge_ports:
                                subtree.append(['EdgeIntf(%s)' % port,
                                                nbr.peer_hostname])
                            else:
                                subtree.append(['Intf(%s)' % port,
                                                nbr.peer_hostname])
                        else:
                            if port in br_mstp_info.edge_ports:
                                subtree.append(['EdgeIntf(%s)' % port, ''])
                            else:
                                subtree.append(['Intf(%s)' % port, ''])
        if subtree:
            if top:
                stpmap.append(
                    [utils.color_wrap(BgColors.GREEN, 'Root(%s)' % node_at),
                     subtree]
                )
            else:
                stpmap.append([node_at, subtree])
        else:
            if top:
                stpmap.append(
                    [utils.color_wrap(BgColors.GREEN, 'Root(%s)' % node_at), '']
                )
            else:
                stpmap.append([node_at, ''])

        if visit_peer and peername:
            # We empty the visited nodes when visiting peer because
            # we can potentially be visiting the same nodes again via the peer
            stppeermap = self.build_stp_topo(peername, brname, False, False, [])
            stpmap.append(stppeermap)

        return stpmap

    def get_stp_topo(self, hostname, brname, visit_peer):
        """Do some initial work before handing off to building the topo
        """
        bridges = {}
        entries = MstpInfo.query.filter(timestamp=self.__start_time,
                                        hostname=hostname,
                                        bridge_name=brname)
        for entry in entries:
            if entry.root_bridge not in bridges:
                bridges[entry.root_bridge] = []
            bridges[entry.root_bridge].append([entry.hostname,
                                               entry.bridge_name])
        if not bridges:
            raise NetQException('No bridges found')
        elif len(bridges) > 1:
            err_str = ('Multiple disconnected bridges found. '
                       'Please specify host and/or bridge name')
            if bridges:
                err_str += '\nbridges: %s' % bridges
            raise NetQException(err_str)

        for key in bridges.keys():
            root = key.split('.')[2]

            # Identify node name that is the root bridge
            node_at = self.__get_stp_root(root)
            if not node_at:
                raise NetQException(
                    'Error: Unable to identify root bridge %s' % root
                )
            self.__build_lldp_info()
            self.__build_failed_node_lst()
            return self.build_stp_topo(node_at, bridges[key][0][1], visit_peer,
                                       True, [])

    def resolve_output(self):
        """Replace the IP address in output with node name & interface
        if possible.
        """
        prev = HOSTNAME
        traceroute = False
        pmtu_failure = False
        mtu_string = ''
        out = []
        for line in sys.stdin:
            addresses = {}
            prev_save = None
            if not traceroute and line.startswith('traceroute'):
                self.__build_lldp_info()
                traceroute = True
                mtu = 0
                mtu_string = ''

            for addr in self.__IP_ADDR_REGEX.findall(line):
                try:
                    if '/' in addr:
                        _ = ipaddr.IPNetwork(addr)
                        prefix, mask = addr.split('/')
                        addrobj = Address.query.get(
                            timestamp=self.__start_time,
                            prefix=prefix,
                            mask=mask
                        )
                    else:
                        _ = ipaddr.IPAddress(addr)
                        addrobj = Address.query.get(
                            timestamp=self.__start_time,
                            prefix=addr
                        )
                except Exception:  # pylint: disable=broad-except
                    continue

                if addrobj is None:
                    continue

                if traceroute and prev is not None:
                    pmtu_error = ''
                    lldp = Lldp.query.get(hostname=prev,
                                          peer_hostname=addrobj.hostname)
                    if lldp is not None:
                        local_link = Link.query.get(
                            timestamp=self.__start_time,
                            ifname=lldp.ifname,
                            hostname=prev)
                        if local_link:
                            if mtu == 0:
                                mtu = int(local_link.mtu)
                                mtu_string = '%s:%s, MTU %d' % (prev,
                                                                lldp.ifname,
                                                                mtu)

                            if mtu != local_link.mtu:
                                pmtu_error = '*'
                                pmtu_failure = True
                        remote_link = Link.query.get(
                            timestamp=self.__start_time,
                            ifname=lldp.peer_ifname,
                            hostname=lldp.peer_hostname
                        )
                        if remote_link and mtu != int(remote_link.mtu):
                            pmtu_error = '*'
                            pmtu_failure = True

                        if '*' in pmtu_error:
                            addr_tuple = (
                                utils.color_wrap(BgColors.RED,
                                                 lldp.peer_hostname),
                                utils.color_wrap(BgColors.RED,
                                                 lldp.peer_ifname),
                                pmtu_error)
                        else:
                            addr_tuple = (
                                utils.color_wrap(BgColors.GREEN,
                                                 lldp.peer_hostname),
                                utils.color_wrap(BgColors.GREEN,
                                                 lldp.peer_ifname))

                        addresses[addr] = addr_tuple
                    else:
                        addr_tuple = (
                            utils.color_wrap(BgColors.GREEN, addrobj.hostname),
                            utils.color_wrap(BgColors.GREEN, addrobj.ifname)
                        )
                        addresses[addr] = addr_tuple
                else:
                    addr_tuple = (
                        utils.color_wrap(BgColors.GREEN, addrobj.hostname),
                        utils.color_wrap(BgColors.GREEN, addrobj.ifname)
                    )
                    addresses[addr] = addr_tuple

                if not line.startswith('traceroute') and not prev_save:
                    prev_save = addrobj.hostname

            for addr in addresses:
                addr_str = '%s (%s)' % (addr, ':'.join(addresses[addr]))
                if traceroute:
                    line = line.replace(addr, addr_str, 1)
                    line = line.replace(' (%s)' % addr, '', 1)
                else:
                    line = line.replace(addr, addr_str)
            out.append(line)

            if not line.startswith('traceroute'):
                prev = prev_save

        if pmtu_failure:
            out.append(
                '* - Links with mismatched MTU from origin %s' %
                mtu_string
            )
        elif traceroute:
            if mtu == 0:
                out.append('Path MTU couldn\'t be determined')
            else:
                out.append('Path MTU is %d' % mtu)

        return ''.join(out)

    def show_address_history(self, node, iface, ip_address, mac, ipv6=None):
        out = []
        if not ipv6:
            if ip_address == '*':
                ipv6 = '*'
            else:
                ipv6 = ':' in ip_address

        now = time.time()
        if '/' in ip_address:
            prefix, mask = ip_address.split('/')
            active_entries = Address.query.rangebyscore(
                prefix=prefix, mask=mask, active=True, is_ipv6=ipv6,
                hostname=node, ifname=iface,
                start=self.__start_time or 0, end=now, first=False
            )
            inactive_entries = Address.query.rangebyscore(
                prefix=prefix, mask=mask, active=False, is_ipv6=ipv6,
                hostname=node, ifname=iface,
                start=self.__start_time or 0, end=now, first=False
            )
        else:
            active_entries = Address.query.rangebyscore(
                prefix=ip_address, active=True, is_ipv6=ipv6,
                hostname=node, ifname=iface,
                start=self.__start_time or 0, end=now, first=False
            )
            inactive_entries = Address.query.rangebyscore(
                prefix=ip_address, active=False, is_ipv6=ipv6,
                hostname=node, ifname=iface,
                start=self.__start_time or 0, end=now, first=False
            )
        for address in sorted(list(active_entries) + list(inactive_entries),
                              key=lambda x: x.timestamp,
                              reverse=True):
            out.append(('/'.join((address.prefix, str(address.mask))),
                        address.hostname, address.ifname, address.active,
                        address.timestamp))
        return out

    def show_addresses(self, node, iface, ip_address, mac):

        vrr_iface = None
        if mac == '*':
            want_ipv6 = not ip_address or ':' in ip_address
            if '/' in ip_address:
                prefix, mask = ip_address.split('/')
            else:
                prefix = ip_address
                mask = '*'

        # Ripping out MAC-based query support for now as it wasn't working
        if mac != '*':
            entries = self.show_macvlan(mac, '*', node, origin=True)
        elif ip_address == '*':
            # MAC and IP are unspecified, so its node/interface specific
            entries = Address.query.filter(timestamp=self.__start_time,
                                           endtimestamp=self.__end_time,
                                           hostname=node, ifname=iface,
                                           prefix=prefix, mask=mask)
            mac_entries = Link.query.filter(timestamp=self.__start_time,
                                            endtimestamp=self.__end_time,
                                            hostname=node, ifname=iface)
            # Get link type and if its a VLAN, see if it has a VRR component
            link = Link.query.get(timestamp=self.__start_time,
                                  endtimestamp=self.__end_time,
                                  hostname=node, ifname=iface)
            if link and link.kind == LinkType.VLAN:
                # Thanks to NCLU, we may have one of two formats for the
                # VLAN interface: <if>.<vlanid> or just vlan<id>
                if '.' in iface:
                    ifsplit = iface.split('.')
                    vrr_iface = '%s-%s-v0' % (ifsplit[0], ifsplit[1])
                else:
                    vrr_iface = '%s-v0' % iface
                vrr_entries = Address.query.filter(timestamp=self.__start_time,
                                                   endtimestamp=self.__end_time,
                                                   hostname=node,
                                                   ifname=vrr_iface)
                vrr_mac_entries = Link.query.filter(
                    timestamp=self.__start_time, endtimestamp=self.__end_time,
                    hostname=node, ifname=vrr_iface
                )
            else:
                vrr_entries = []
                vrr_mac_entries = []
                vrr_iface = None
            entries = (
                list(entries) + list(mac_entries) + list(vrr_entries) +
                list(vrr_mac_entries)
            )
        else:
            entries = Address.query.filter(timestamp=self.__start_time,
                                           endtimestamp=self.__end_time,
                                           hostname=node, ifname=iface,
                                           prefix=prefix, mask=mask,
                                           is_ipv6=want_ipv6)
        out = []
        for address in entries:
            if isinstance(address, Address):
                ipa = address.prefix + '/' + str(address.mask)
                loopback_addr = ['127.0.0.1/8', '::1/128']
                if ipa in loopback_addr:
                    continue
                if vrr_iface and address.ifname == vrr_iface:
                    if address.prefix.startswith('fe80::'):
                        continue
                    address.ifname = 'VRR'
                out.append(('/'.join((address.prefix, str(address.mask))),
                            address.hostname, address.ifname,
                            address.timestamp))
            elif isinstance(address, Link):
                if vrr_iface and address.ifname == vrr_iface:
                    address.ifname = 'VRR'
                out.append([address.mac_address, address.hostname,
                            address.ifname, address.timestamp])
            else:
                # show_macvlan doesn't return objects unfortunately and so we
                # need to iterate over the objects now
                for entry in address:
                    # This is bad. We're hardcoding the result of macvlan
                    # The fields are: MAC, nodename, nexthop, timestamp
                    out.append(['(%s, %s)' % (entry[0], entry[1]), entry[2],
                                entry[3], entry[-1]])

            if len(out) >= RedisQuery.PAGE_SIZE:
                yield out
                out = []
        if out:
            yield out

    @staticmethod
    def show_agent_history(hostname=None):
        if hostname is not None:
            query = Node.query.range(start=0,
                                     end=-1,
                                     first=False,
                                     reverse=True,
                                     active=True,
                                     hostname=hostname)
        else:
            query = Node.query.range(start=0,
                                     end=-1,
                                     first=False,
                                     active=True,
                                     reverse=True)
        for obj in query:
            yield obj.hostname, obj.lastboot, obj.timestamp

    def show_asn(self, asn):
        out = []
        if asn is None:
            nodes = BgpSession.query.all(timestamp=self.__start_time)
        else:
            nodes = BgpSession.query.filter(timestamp=self.__start_time,
                                            asn=asn)
        for node in nodes:
            out.append((node.peer_asn, node.hostname, node.peer_router_id))
        return out

    def check_bgp_status(self):
        out = []
        good_out = []
        self.__build_failed_node_lst()
        self.__build_lldp_info()  # Also builds the failed node set

        for node in self.failed_node_lst:
            err_str = 'Rotten Agent State'
            out.append([node, '', '', err_str, self.failed_node_lst[node]])

        for node in self.node_lst:
            for session in BgpSession.query.filter(timestamp=self.__start_time,
                                                   hostname=node.hostname):
                if session.state != 'Established':
                    if session.peer_hostname != '':
                        out.append([session.hostname, session.peer_name,
                                    session.peer_hostname, session.reason,
                                    session.last_reset_time])
                    else:
                        out.append([session.hostname, session.peer_name,
                                    session.peer_router_id, session.reason,
                                    session.last_reset_time])
                elif node not in self.failed_node_lst:
                    if session.peer_hostname != '':
                        good_out.append([session.hostname, session.peer_name,
                                         session.peer_hostname, '', 0])
                    else:
                        good_out.append([session.hostname, session.peer_name,
                                         session.peer_router_id, '', 0])

        return good_out, out

    def show_keys(self, hostname):
        out = []
        key_map = {}
        cmds = Command.query.filter(hostname=hostname, key='*')
        for cmd in cmds:
            key_map[Command.obj_to_key(cmd.__dict__)] = cmd
        for key, count, oldest, newest in Command.query.count(key_map.keys()):
            out.append((key_map[key].key.replace('-', ' '), float(oldest),
                        float(newest), count))
        return out

    def check_clag_status(self):
        out = []
        good_out = []
        rotten_nodenames = []
        clag_sysmac_dict = {}

        self.__build_failed_node_lst()
        self.__build_lldp_info()

        for node in self.failed_node_lst:
            err_str = 'Rotten Agent State'
            out.append([node, err_str])
            rotten_nodenames.append(node)

        for clag in ClagSession.query.filter(timestamp=self.__start_time):
            failed = 0
            peerlen = len(clag_sysmac_dict.get(clag.clag_sysmac, []))
            if not peerlen:
                peername = self.__get_clag_peer_hostname(clag.hostname,
                                                         clag.peer_if)
                clag_sysmac_dict[clag.clag_sysmac] = [clag.hostname, peername]
                if clag.backup_ip != '':
                    peer_ipif = Address.query.get(
                        timestamp=self.__start_time,
                        prefix=clag.backup_ip,
                        is_ipv6=':' in clag.backup_ip
                    )
                    if(peer_ipif and peername != '*' and
                       peer_ipif.hostname != peername):
                        out.append(
                            [clag.hostname,
                             ('Backup IP %s set to wrong host: %s '
                              'instead of %s' % (peer_ipif.prefix,
                                                 peer_ipif.hostname,
                                                 clag.hostname))]
                        )
                        failed = 1
            elif '*' in clag_sysmac_dict[clag.clag_sysmac]:
                # We couldn't identify the peers due to lack of lldp
                # this one takes the cake as the peer for now
                peers = clag_sysmac_dict[clag.clag_sysmac]
                if peers[0] == '*':
                    clag_sysmac_dict[clag.clag_sysmac] = [clag.hostname,
                                                          peers[1]]
                else:
                    clag_sysmac_dict[clag.clag_sysmac] = [peers[0],
                                                          clag.hostname]
            elif clag.hostname not in clag_sysmac_dict[clag.clag_sysmac]:
                dup_peers = clag_sysmac_dict[clag.clag_sysmac]
                out.append([clag.hostname,
                            ('Duplicate sysmac with %s/%s' %
                             (dup_peers[0], dup_peers[1]))])

                failed = 1
            else:
                peers = clag_sysmac_dict[clag.clag_sysmac]
                if peers[0] == clag.hostname:
                    peername = peers[1]
                else:
                    peername = peers[0]
                    peer_ipif = Address.query.get(
                        timestamp=self.__start_time,
                        prefix=clag.backup_ip,
                        is_ipv6=':' in clag.backup_ip
                    )
                    if(peer_ipif and peername != '*' and
                       peer_ipif.hostname != peername):
                        out.append(
                            [clag.hostname,
                             ('Backup IP %s set to wrong host: %s '
                              'instead of %s' % (peer_ipif.prefix,
                                                 peer_ipif.hostname,
                                                 peername))]

                        )
                        failed = 1

            if not clag.peer_state:
                err_str = 'Peer Connectivity failed'
                out.append([clag.hostname, err_str])
                failed = 1
            if clag.conflicted_bonds:
                ele_list = []
                for ele in clag.conflicted_bonds:
                    ele_list.append('%s:%s' % (ele[0].encode('ascii',
                                                             'ignore'),
                                               ele[1].encode('ascii',
                                                             'ignore')))
                err_str = 'Conflicted Bonds: %s' % (', '.join(ele_list))
                out.append([clag.hostname, err_str])
                failed = 1
            if clag.proto_down_bonds:
                ele_list = []
                for ele in clag.proto_down_bonds:
                    ele_list.append('%s:%s' % (ele[0].encode('ascii',
                                                             'ignore'),
                                               ele[1].encode('ascii',
                                                             'ignore')))
                err_str = 'Protodown Bonds: %s' % (', '.join(ele_list))
                out.append([clag.hostname, ele_list])
                failed = 1

            if not failed and clag.hostname not in rotten_nodenames:
                good_out.append([clag.hostname, ''])

        return good_out, out

    def show_stp_status(self):
        """Show health of STP across the fabric
        """
        failed_node_lst = []
        # Verify that for all bridges, the root is the same
        # Verify that designated agreement exists on both sides (except
        # alternate root)
        for node in self.node_lst:
            for mstpi in MstpInfo.query.filter(timestamp=self.__start_time,
                                               hostname=node.hostname):
                if mstpi.bpduguard_err_ports:
                    err_str = (
                        'BPDUGuard Error %s' %
                        ' '.join(mstpi.bpduguard_err_ports)
                    )
                    failed_node_lst.append([MstpStatus.BPDUGUARD_ERR,
                                            err_str,
                                            mstpi.hostname])
                if mstpi.disputed_ports:
                    err_str = ('Disputed ports: %s' %
                               ' '.join(mstpi.disputed_ports))
                    failed_node_lst.append([MstpStatus.DISPUTED,
                                            err_str,
                                            mstpi.hostname])
                if mstpi.ba_inconsistent_ports:
                    err_str = ('BA Inconsistent ports: %s' %
                               ' '.join(mstpi.ba_inconsistent_ports))
                    failed_node_lst.append([MstpStatus.BA_INCONSISTENT,
                                            err_str,
                                            mstpi.hostname])

    def get_services_status(self, hostname, service):
        """Get status of (specified)service for (specified)hosts
        """
        out = []

        self.__build_failed_node_lst()
        for svc in Services.query.filter(timestamp=self.__start_time,
                                         hostname=hostname, name=service):
            if svc.hostname in self.failed_node_lst:
                status = svc.timestamp
            else:
                status = 'current'
            out.append([svc.hostname, svc.name, svc.is_enabled,
                        svc.is_active, svc.is_monitored, status])

        return out

    def show_info(self, ip_address=None, mac_address=None, node=None):
        """
        Get all relevant info about provided input
        """
        display = []
        self.__build_lldp_info(None)
        self.__build_failed_node_lst()

        if ip_address is not '*':
            # Attempt to determine if we can identify the end node
            out = []
            neighbors = Neighbor.query.filter(timestamp=self.__start_time,
                                              ip_address=ip_address)
            for neighbor in neighbors:
                macs = MacFdb.query.filter(timestamp=self.__start_time,
                                           mac_address=neighbor.mac_address)
                for entry in macs:
                    lldpnbrs = Lldp.query.filter(timestamp=self.__start_time,
                                                 hostname=neighbor.hostname,
                                                 ifname=entry.nexthop)
                    for lldpnbr in lldpnbrs:
                        display.append(
                            '%s belongs to %s, connected to %s:%s\n' % (
                                ip_address, lldpnbr.peer_hostname,
                                neighbor.hostname, entry.nexthop)
                        )
                out.append((neighbor.ip_address, neighbor.hostname,
                            neighbor.ifname, neighbor.mac_address))
                if out:
                    display.append('IP Neighbor Information:')
                    display.append(tabulate(sorted(out),
                                            headers=['IP', 'Node', 'Interface',
                                                     'MAC']))

        elif mac_address is not '*':
            mac_entries = MacFdb.query.filter(timestamp=self.__start_time,
                                              mac_address=mac_address)
            for entry in mac_entries:
                lldpnbrs = Lldp.query.filter(timestamp=self.__start_time,
                                             hostname=entry.hostname,
                                             ifname=entry.nexthop)
                for lldpnbr in lldpnbrs:
                    display.append('%s belongs to %s, connected to %s:%s\n' %
                                   (mac_address, lldpnbr.peer_hostname,
                                    entry.hostname, entry.nexthop))
            neighbors = Neighbor.query.filter(timestamp=self.__start_time,
                                              mac_address=mac_address,
                                              is_ipv6=False)
            out = []
            for neighbor in neighbors:
                out.append((neighbor.ip_address, neighbor.hostname,
                            neighbor.ifname, neighbor.mac_address))
            if out:
                display.append('List of IP Neighbor entries')
                display.append(tabulate(sorted(out),
                                        headers=['IP', 'Node', 'Interface',
                                                 'MAC']))

        elif node is not '*':
            if Node.query.get(hostname=node) is None:
                raise NetQException('No information about %s found' % node)

            # OK, this is a hostname. Display all valid info about host
            display.append('Info about node %s' % node)
            services = []
            cmd = Command.query.get(timestamp=self.__start_time,
                                    hostname=node,
                                    key='bgp-summary*')
            if cmd and 'bgpd is not running' not in cmd.output:
                services.append('BGP')

            cmd = Command.query.get(timestamp=self.__start_time,
                                    hostname=node,
                                    key='clagctl*')
            if cmd and 'Unable to communicate ' not in cmd.output:
                services.append('CLAG')

            cmd = Command.query.get(timestamp=self.__start_time,
                                    hostname=node,
                                    key='ospf*')
            if cmd and 'ospfd is not running' not in cmd.output:
                services.append('OSPF')

            cmd = Command.query.get(timestamp=self.__start_time,
                                    hostname=node,
                                    key='mstp*')
            if cmd and 'Usage' not in cmd.output:
                services.append('MSTP')

            cmd = Command.query.get(timestamp=self.__start_time,
                                    hostname=node,
                                    key='lldp-neighbor')
            if cmd and 'unable to connect' not in cmd.output:
                services.append('LLDP')

            uptime = Command.query.get(timestamp=self.__start_time,
                                       hostname=node,
                                       key=NetQ.UPTIME_KEY)
            if uptime is not None:
                display.append('uptime %s' % uptime.output.strip())

            meminfo = Command.query.get(timestamp=self.__start_time,
                                        hostname=node,
                                        key=NetQ.MEMINFO_KEY)
            if meminfo is not None:
                display.append('Free Memory: %s' %
                               meminfo.output.split('\n')[1].
                               split(':')[1].strip())

            routes = Route.query.filter(timestamp=self.__start_time,
                                        hostname=node)
            macs = MacFdb.query.filter(timestamp=self.__start_time,
                                       hostname=node)

            display.append('Total routes: %d' % len(list(routes)))
            display.append('Total macs: %d' % len(list(macs)))
            display.append('Services running: %s' % ', '.join(services))

        return '\n'.join(display)

    def show_ip_neighbor_history(self, hostname='*', ifname='*',
                                 ip_address='*', mac='*', ipv6=False):
        out = []
        now = time.time()
        if hostname != '*' and ifname != '*':
            active_entries = Neighbor.query.rangebyscore(
                hostname=hostname, ifname=ifname, active=True,
                mac_address=mac, is_ipv6=ipv6,
                start=self.__start_time or 0, end=now, first=False
            )
            inactive_entries = Neighbor.query.rangebyscore(
                hostname=hostname, ifname=ifname, active=False,
                mac_address=mac, is_ipv6=ipv6,
                start=self.__start_time or 0, end=now, first=False
            )
        else:
            active_entries = Neighbor.query.rangebyscore(
                ip_address=ip_address, active=True, mac_address=mac,
                is_ipv6=ipv6, start=self.__start_time or 0, end=now,
                first=False
            )
            inactive_entries = Neighbor.query.rangebyscore(
                ip_address=ip_address, active=False, mac_address=mac,
                is_ipv6=ipv6, start=self.__start_time or 0, end=now,
                first=False
            )
        for neighbor in sorted(list(active_entries) + list(inactive_entries),
                               key=lambda x: x.timestamp,
                               reverse=True):
            out.append((neighbor.ip_address, neighbor.hostname,
                        neighbor.ifname, neighbor.mac_address, neighbor.active,
                        neighbor.timestamp))
        return out

    def show_ip_neighbors(self, ip_address, hostname, iface, mac, ipv6=False):
        out = []
        for neighbor in Neighbor.query.filter(timestamp=self.__start_time,
                                              endtimestamp=self.__end_time,
                                              ip_address=ip_address,
                                              hostname=hostname,
                                              ifname=iface,
                                              mac_address=mac,
                                              is_ipv6=ipv6):
            if neighbor is None:
                out.append(None)
                continue
            if neighbor.ifname == 'lo':
                continue
            if neighbor.ip_address == 'None':
                continue
            out.append((neighbor.ip_address, neighbor.hostname,
                        neighbor.ifname, neighbor.mac_address,
                        neighbor.timestamp))
            if len(out) >= RedisQuery.PAGE_SIZE:
                yield out
                out = []
        if out:
            yield out

    def show_link_history(self, hostname, ifname, kind='*'):
        self.__build_failed_node_lst()
        self.__build_lldp_info(None)
        out = []
        now = time.time()
        active_entries = list(
            Link.query.rangebyscore(hostname=hostname,
                                    ifname=ifname, kind=kind, active=True,
                                    start=self.__start_time or 0,
                                    end=now, first=False)
        )
        inactive_entries = list(
            Link.query.rangebyscore(hostname=hostname, ifname=ifname, kind=kind,
                                    active=False, start=self.__start_time or 0,
                                    end=now, first=False)
        )
        for link in sorted(active_entries + inactive_entries,
                           key=lambda x: x.timestamp,
                           reverse=True):
            details = self.__get_link_details(link)
            out.append((link.hostname, link.ifname, link.oper_state,
                        details, link.active, link.timestamp))
        return out

    def show_links(self, hostname=None, ifname=None, kind='*'):
        self.__build_failed_node_lst()
        self.__build_lldp_info(None)
        out = []
        links = Link.query.filter(timestamp=self.__start_time,
                                  endtimestamp=self.__end_time,
                                  hostname=hostname,
                                  ifname=ifname, kind=kind)
        self.__end_time = None
        for link in links:
            if link is None:
                out.append(None)
                continue
            self.__start_time = link.timestamp
            details = self.__get_link_details(link)
            out.append((link.hostname, link.ifname, link.kind, link.oper_state,
                        details, link.timestamp))
            if len(out) >= RedisQuery.PAGE_SIZE:
                yield out
                out = []
        if out:
            yield out

    def show_mac_history(self, mac_address, vlan='*', hostname='*',
                         nexthop='*', origin='*'):
        out = []
        now = time.time()
        self.__build_lldp_info()
        known_nodes = [node.hostname for node in self.node_lst]

        active_entries = MacFdb.query.rangebyscore(
            mac_address=mac_address, hostname=hostname, vlan=vlan,
            active=True, start=self.__start_time or 0, end=now, first=False
        )
        inactive_entries = MacFdb.query.rangebyscore(
            mac_address=mac_address, hostname=hostname, vlan=vlan,
            active=False, start=self.__start_time or 0, end=now, first=False
        )

        for macfdb in sorted(list(active_entries) + list(inactive_entries),
                             key=lambda x: x.timestamp,
                             reverse=True):
            if macfdb:
                result = self.__process_show_fdb_entry(macfdb, nexthop,
                                                       origin, known_nodes)
                if not result:
                    continue

                result.extend([macfdb.active])
                out.append(result)

                if len(out) >= RedisQuery.PAGE_SIZE:
                    yield out
                    out = []
        if out:
            yield out

    def show_macvlan(self, mac_address, vlan, hostname, nexthop='*',
                     origin='*'):

        self.__build_lldp_info()
        out = []
        known_nodes = [node.hostname for node in self.node_lst]

        fdb_entries = MacFdb.query.filter(timestamp=self.__start_time,
                                          endtimestamp=self.__end_time,
                                          hostname=hostname,
                                          mac_address=mac_address, vlan=vlan)

        for entry in fdb_entries:
            if entry:
                result = self.__process_show_fdb_entry(entry, nexthop, origin,
                                                       known_nodes)
                if result:
                    out.append(result)

                if len(out) >= RedisQuery.PAGE_SIZE:
                    yield out
                    out = []
        if out:
            yield out

    def show_neighbors(self, node, iface):
        self.__build_failed_node_lst()
        self.__build_lldp_info(node)
        out = []
        if iface is not '*':
            lldplist = Lldp.query.filter(timestamp=self.__start_time,
                                         hostname=node,
                                         ifname=iface)
        else:
            lldplist = Lldp.query.all(timestamp=self.__start_time)
        for lldpobj in lldplist:
            out.append((lldpobj.hostname, lldpobj.ifname,
                        lldpobj.peer_hostname, lldpobj.peer_ifname,
                        lldpobj.timestamp))
        return out

    def show_route_history(self, ip_address, hostname='*', ipv6=False):
        out = []
        now = time.time()
        active_entries = Route.query.rangebyscore(
            ip_address=ip_address, hostname=hostname, active=True,
            is_ipv6=ipv6,
            start=self.__start_time or 0, end=now, first=False
        )
        inactive_entries = Route.query.rangebyscore(
            ip_address=ip_address, hostname=hostname, active=False,
            is_ipv6=ipv6,
            start=self.__start_time or 0, end=now, first=False
        )
        for route in sorted(list(active_entries) + list(inactive_entries),
                            key=lambda x: x.timestamp,
                            reverse=True):
            nexthops = ', '.join(
                '%s: %s' % (nh[0], nh[1]) if isinstance(nh, list) else nh
                for nh in route.nexthops
            )
            out.append((route.ip_address, route.hostname, nexthops,
                        route.origin, route.active, route.timestamp))
        return out

    def show_router_id(self, router_id):
        out = []
        nodes = BgpSession.query.all(timestamp=self.__start_time)
        for node in nodes:
            if router_id is not None and node.peer_router_id != router_id:
                continue
            out.append((node.peer_router_id, node.hostname, node.peer_asn))
        return out

    def show_routes(self, prefix, hostname, ipv6=False, origin='*'):
        skip_ipv4_addr = {'127.0.0.0/8', '127.0.0.1/32', '127.0.0.0/32',
                          '127.255.255.255/32', '169.254.0.1/32'}
        skip_ipv6_addr = {'fe80::/64', '::/0', '::1/128', 'ff00::/8'}
        if hostname is not '*':
            nodes = [hostname]
        else:
            nodes = [node.hostname for node in self.node_lst]
        if prefix is not '*':
            entries = Route.query.lpm(prefix, nodes,
                                      timestamp=self.__start_time,
                                      is_ipv6=ipv6)
        elif hostname is not '*':
            entries = Route.query.filter(timestamp=self.__start_time,
                                         endtimestamp=self.__end_time,
                                         hostname=hostname,
                                         is_ipv6=ipv6)
        else:
            entries = Route.query.filter(timestamp=self.__start_time,
                                         endtimestamp=self.__end_time,
                                         is_ipv6=ipv6)
        out = []
        for route in entries:
            if route is None:
                out.append(None)
                continue
            if not route.is_ipv6 and route.ip_address in skip_ipv4_addr:
                continue
            if route.is_ipv6 and route.ip_address in skip_ipv6_addr:
                continue
            if not route.nexthops:
                route.nexthops = ['Local']
            if origin is '*' or origin == route.origin:
                nexthops = ', '.join(
                    '%s: %s' % (nh[0], nh[1]) if isinstance(nh, list)
                    else nh for nh in sorted(route.nexthops)
                )
                out.append((route.origin,
                            route.table,
                            route.ip_address,
                            route.hostname,
                            nexthops,
                            route.timestamp))
                if len(out) >= RedisQuery.PAGE_SIZE:
                    yield out
                    out = []
        if out:
            yield out

    def show_status(self):
        out = []
        for node in self.node_lst:
            ago = node.timestamp
            last_beat = (datetime.utcnow() -
                         datetime.utcfromtimestamp(int(node.timestamp)))
            if last_beat.total_seconds() > Heartbeat.HEARTBEAT_DEATH:
                status = AgentHealth.ROTTEN
            elif last_beat.total_seconds() <= Heartbeat.LIVELINESS_RATE:
                status = AgentHealth.FRESH
            else:
                status = AgentHealth.STALE
            out.append([str(node), node.lastboot, ago, status])
        return out

    def top_talkers_rx(self, count):
        return self.__top_talkers(count,
                                  [Counter.RX_BPS,
                                   Counter.RX_DROP_BPS,
                                   Counter.RX_ERR_BPS])

    def top_talkers_tx(self, count):
        return self.__top_talkers(count,
                                  [Counter.TX_BPS,
                                   Counter.TX_DROP_BPS,
                                   Counter.TX_ERR_BPS])

    def view(self, node, key):
        cmd = Command.query.get(timestamp=self.__start_time,
                                hostname=node,
                                key='-'.join(key))
        if cmd is None:
            raise NetQException(
                'Could\'nt locate command output for key %s' % ' '.join(key)
            )
        return cmd.timestamp, cmd.output

    def check_vlan_consistency(self, hostname='*', ifname=None):
        """Check all links have consistent VLANs
        """
        visited_links = {}
        unverified_links = []
        pvid_mismatch_links = []
        output = []

        self.__build_failed_node_lst()
        self.__build_lldp_info()
        br_ifname = '*'

        if ifname:
            link_if = Link.query.get(timestamp=self.__start_time,
                                     hostname=hostname, ifname=ifname)
            if link_if:
                if link_if.kind == LinkType.BRIDGE:
                    br_ifname = ifname
                elif link_if.kind == LinkType.BOND:
                    pass
                elif link_if.kind == LinkType.SWP:
                    if link_if.master != '':
                        master_if = Link.query.get(timestamp=self.__start_time,
                                                   hostname=hostname,
                                                   ifname=link_if.master)
                        if master_if:
                            if master_if.kind == LinkType.BOND:
                                ifname = master_if.ifname
                            elif master_if.kind == LinkType.BRIDGE:
                                br_ifname = master_if.ifname
                            else:
                                raise NetQException(
                                    'Link %s is not of type bond or bridge '
                                    'or swp' % link_if.ifname
                                )
                else:
                    raise NetQException(
                        'Link %s is not of type bond or bridge '
                        'or swp' % link_if.ifname
                    )

        bridges = Link.query.filter(timestamp=self.__start_time,
                                    hostname=hostname, ifname=br_ifname,
                                    kind=LinkType.BRIDGE)

        # For each bridge listed, visit every link and verify its vlan
        # consistency.
        for bridge in bridges:
            if not bridge.is_vlan_filtering:
                # Support coming in a later release
                continue

            for br_ifname in bridge.slaves:
                br_ifname = br_ifname.encode('ascii', 'ignore')
                if ifname and br_ifname != ifname:
                    continue
                if bridge.hostname not in visited_links:
                    visited_links[bridge.hostname] = []

                if br_ifname in visited_links[bridge.hostname]:
                    continue
                else:
                    visited_links[bridge.hostname].append(br_ifname)

                br_if = Link.query.get(timestamp=self.__start_time,
                                       hostname=bridge.hostname,
                                       ifname=br_ifname)
                if not br_if:
                    continue

                # Now get its peer and check its vlan list
                nbr = None
                if br_if.kind and br_if.kind == LinkType.BOND:
                    for bond_slave in br_if.slaves:
                        bond_slave = bond_slave.encode('ascii', 'ignore')
                        nbr = Lldp.query.get(timestamp=self.__start_time,
                                             hostname=bridge.hostname,
                                             ifname=bond_slave)
                        if nbr:
                            break
                    # Check if this is part of CLAG and if so that
                    # its peer has the same config
                    clag_session = ClagSession.query.get(
                        timestamp=self.__start_time, hostname=bridge.hostname
                    )
                    if clag_session:
                        clag_peer_if = clag_session.dual_bonds.get(
                            br_ifname, None
                        )
                        peer_hostname = self.__get_clag_peer_hostname(
                            bridge.hostname, clag_session.peer_if)
                        if peer_hostname != '*' and clag_peer_if:
                            c_if = Link.query.get(
                                timestamp=self.__start_time,
                                hostname=peer_hostname,
                                ifname=clag_peer_if.encode('ascii', 'ignore')
                            )
                            if c_if:
                                if not self.__compare_vlans(br_if.vlans,
                                                            c_if.vlans):
                                    output.append(
                                        [bridge.hostname, br_if.ifname,
                                         br_if.vlans, peer_hostname,
                                         c_if.ifname, c_if.vlans])

                                if br_if.access_vlan != c_if.access_vlan:
                                    pvid_mismatch_links.append([bridge.hostname,
                                                                br_if.ifname,
                                                                br_if.access_vlan,
                                                                peer_hostname,
                                                                c_if.ifname,
                                                                c_if.access_vlan])
                elif br_if.kind == LinkType.VXLAN:
                    # Should we be comparing the VNI/VLAN mapping ?
                    continue
                else:
                    nbr = Lldp.query.get(timestamp=self.__start_time,
                                         hostname=bridge.hostname,
                                         ifname=br_if.ifname)

                if not nbr:
                    unverified_links.append([bridge.hostname,
                                             br_if.ifname, br_if.vlans, '', ''])
                    continue

                if nbr.peer_hostname not in visited_links:
                    visited_links[nbr.peer_hostname] = []

                r_if = Link.query.get(timestamp=self.__start_time,
                                      hostname=nbr.peer_hostname,
                                      ifname=nbr.peer_ifname)
                if not r_if:
                    # We don't check any other type because LLDP is only on
                    # physical links
                    unverified_links.append([bridge.hostname,
                                             br_if.ifname, br_if.vlans,
                                             nbr.peer_hostname,
                                             nbr.peer_ifname])
                    if nbr.peer_ifname in visited_links[nbr.peer_hostname]:
                        visited_links[nbr.peer_hostname].append(
                            nbr.peer_ifname
                        )
                    continue

                if r_if.master != '':
                    # So we have a master link. Get that link's info.
                    m_if = Link.query.get(timestamp=self.__start_time,
                                          hostname=nbr.peer_hostname,
                                          ifname=r_if.master)
                    if not m_if or m_if.vlans == '':
                        unverified_links.append([bridge.hostname,
                                                 br_if.ifname,
                                                 br_if.vlans,
                                                 nbr.peer_hostname,
                                                 nbr.peer_ifname])
                        continue

                    if not self.__compare_vlans(br_if.vlans, m_if.vlans):
                        output.append([bridge.hostname, br_if.ifname,
                                       br_if.vlans, nbr.peer_hostname,
                                       m_if.ifname, m_if.vlans])

                    if br_if.access_vlan != m_if.access_vlan:
                        pvid_mismatch_links.append([bridge.hostname,
                                                    br_if.ifname,
                                                    br_if.access_vlan,
                                                    nbr.peer_hostname,
                                                    m_if.ifname,
                                                    m_if.access_vlan])

                    if m_if.ifname not in visited_links[nbr.peer_hostname]:
                        visited_links[nbr.peer_hostname].append(m_if.ifname)

                elif r_if.vlans != '':
                    if not self.__compare_vlans(br_if.vlans, r_if.vlans):
                        output.append([bridge.hostname, br_if.ifname,
                                       br_if.vlans, nbr.peer_hostname,
                                       r_if.ifname, r_if.vlans])

                    if br_if.access_vlan != r_if.access_vlan:
                        pvid_mismatch_links.append([bridge.hostname,
                                                    br_if.ifname,
                                                    br_if.access_vlan,
                                                    nbr.peer_hostname,
                                                    r_if.ifname,
                                                    r_if.access_vlan])

                    if nbr.peer_ifname in visited_links[nbr.peer_hostname]:
                        visited_links[nbr.peer_hostname].append(
                            nbr.peer_ifname
                        )

        return unverified_links, pvid_mismatch_links, output

    def vxlan_trace(self, dst):
        """ Perform a vxlan traceroute from the destination IP address to the
        source.
        :param dst: dst ip address
        """
        cmd = '/usr/sbin/traceroute -n %s' % dst
        tracecmd1 = subprocess.Popen(cmd.split(),
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT)
        first_line = last_line = ''
        for line in iter(tracecmd1.stdout.readline, b''):
            first_line = first_line or line
            last_line = line
        if tracecmd1.returncode == 0:
            raise NetQException('Traceroute to %s failed' % dst)

        # Pull the neighbor MAC address from the IP neighbor table
        try:
            nbrline = subprocess.check_output(['ip', 'neighbor', 'show',
                                               dst]).strip()
            if not nbrline:
                raise NetQException('No ARP entry found for IP %s' % dst)
        except:
            raise NetQException('Unable to find ARP entry for IP %s' % dst)
        words = nbrline.split()
        if words[-1] == 'FAILED' or words[-1] == 'INCOMPLETE':
            raise NetQException('No ARP entry found for IP %s' % dst)
        mac_address = words[4]

        # Get the src VXLAN device
        for smacaddr in MacFdb.query.filter(timestamp=self.__start_time,
                                            mac_address=mac_address):
            if not smacaddr.dst:
                continue
            srcvxlandev = next(
                Link.query.filter(timestamp=self.__start_time,
                                  ifname=smacaddr.nexthop,
                                  hostname=smacaddr.hostname,
                                  kind=LinkType.VXLAN),
                None)
            if srcvxlandev is not None:
                break
        else:
            smacaddr = None
            raise NetQException(
                'Couldn\'t locate VxlanDev obj for mac address %s' %
                mac_address
            )

        # Get the dst VXLAN device
        for dstvxlandev in Link.query.filter(timestamp=self.__start_time,
                                             kind=LinkType.VXLAN,
                                             vni=srcvxlandev.vni):
            if dstvxlandev.localip == smacaddr.dst:
                break
        else:
            raise NetQException(
                'Couldn\'t locate dst VxlanDev obj for vni %s' %
                srcvxlandev.vni
            )

        # Finally, execute a traceroute
        cmd = '/usr/sbin/traceroute -n %s' % dstvxlandev.localip
        tracecmd2 = subprocess.Popen(cmd.split(),
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT)
        idx = 0
        out = []
        for line in iter(tracecmd2.stdout.readline, b''):
            if first_line:
                out.append(first_line.rstrip())
                first_line = ''
                out.append(
                    '---------------------- Underlay -------------------------'
                    '--------'
                )
            else:
                match = re.findall(self.__TRACEROUTE_REGEX, line)
                if match:
                    idx = match[0]
                out.append(line.rstrip())
        if last_line:
            oidx = re.findall(self.__TRACEROUTE_REGEX, last_line)[0]
            out.append(
                '-------------------------------------------------------------'
                '----'
            )
            out.append(last_line.replace(oidx, str(int(idx) + 1), 1).rstrip())
        return '\n'.join(out)

    @staticmethod
    def update_config(server_address):
        try:
            redisdb.ping_server(server_address)
        except Exception:  # pylint: disable=broad-except
            raise RuntimeError('Could not connect to server %s' %
                               server_address)
        conf = config.Config(DefaultPaths.CONF_FILE)
        try:
            conf.set_field(config.Config.CommonConfig.section,
                           config.Config.CommonConfig.server.name,
                           server_address)
        except Exception as ex:
            raise RuntimeError('Failed to update config file %s. Error %s' %
                               (DefaultPaths.CONF_FILE, ex))
        return 'Success!'

    ##########################
    # TAB Completion functions
    ##########################
    @staticmethod
    def view_complete(hostname):
        """Return possible completions for current pos.
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)
        if not hostname:
            return []
        choices = [cmd.key.replace('-', ' ')
                   for cmd in Command.query.filter(hostname=hostname, key='*')]
        return sorted(choices)

    @staticmethod
    def hostname_complete(args, ended_with_space, last_argv):
        """
        Completion for hostname
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)
        for node in Node.query.all():
            if ended_with_space or node.hostname.startswith(last_argv):
                out.append((node.hostname, node.hostname))

        if not out:
            out.append(('<hostname>', 'Remote hostname'))

        return out

    @staticmethod
    def hostname_match(argv_word, use_fuzzy, tab_completing=False):
        """
        <as-path-access-list>
        """
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return True
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        node_lst = sorted(node.hostname for node in Node.query.all())
        if use_fuzzy:
            if ' ' not in argv_word:
                return True
        else:
            for node in node_lst:
                if tab_completing and node.startswith(argv_word):
                    return True
                if argv_word in node:
                    return True
        return False

    @staticmethod
    def interface_complete(args, ended_with_space, last_argv):
        """
        Completion for remote interface name
        """
        out = []
        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = args.get('<hostname>')
        if not hostname:
            return []
        elif isinstance(hostname, list):
            hostname = hostname[0]

        plinks = Link.query.filter(hostname=hostname)
        links = plinks

        for link in links:
            if args.get('lldp'):
                if link.ifname == 'lo':
                    continue

                if link.kind in ['vlan', 'vxlan', 'macvlan']:
                    continue

            if ended_with_space or link.ifname.startswith(last_argv):
                out.append((link.ifname, link.ifname))

        if not out:
            out.append(('<remote-interface>', 'Interface name on %s' %
                        hostname))
        return out

    @staticmethod
    def interface_match(argv_word, use_fuzzy, tab_completing=False):
        """
        Match for remote interface name
        """
        keywords = ['history', 'origin', 'json', 'vlan', 'bond', 'bridge',
                    'eth', 'swp', 'vlan', 'vxlan', 'loopback', 'macvlan']

        if argv_word in keywords:
            return False

        try:
            if ipaddr.IPAddress(argv_word):
                return False
        except ValueError:
            pass

        try:
            if ipaddr.IPNetwork(argv_word):
                return False
        except ValueError:
            if (re.match(r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}',
                         argv_word) or
                    re.match(r'[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}',
                             argv_word)):
                return False

        server_addr = NetQ.__get_config_server_addr()
        if server_addr is None:
            return []
        if server_addr is not None and 'http' in server_addr:
            restapi.set_connection_settings(server_addr)
        else:
            redisdb.set_connection_settings(server_addr)

        hostname = get_hostname()
        if not hostname:
            return []

        plinks = Link.query.filter(hostname=hostname)
        links = plinks
        if links:
            return True
        return False

    @staticmethod
    def generic_match(argv_word, use_fuzzy, tab_completing=False):
        """
        Reject keywords & IP Addr from being accepted as value for params
        """
        keywords = ['history', 'origin', 'json', 'vlan', 'bond', 'bridge',
                    'eth', 'swp', 'vlan', 'vxlan', 'loopback', 'macvlan']

        if argv_word in keywords:
            return False

        try:
            if ipaddr.IPAddress(argv_word):
                return False
        except ValueError:
            pass

        try:
            if ipaddr.IPNetwork(argv_word):
                return False
        except ValueError:
            if (re.match(r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}',
                         argv_word) or
                    re.match(r'[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}',
                             argv_word)):
                return False

        return True

    @property
    def node_lst(self):
        if self.__node_lst is None:
            self.__node_lst = sorted(Node.query.all())
        return self.__node_lst
