# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

import fcntl
import gzip
import logging
import logging.handlers
import os
import sys
import time
import copy
from datetime import datetime
from json import JSONEncoder

import ipaddr

from netq.common import netlink
from netq.common.enums import LogDestination, BgColors


class _CompressedRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """ Extended version of RotatingFileHandler that compresses logs on
    rollover.
    Inspired by http://stackoverflow.com/questions/8467978/
    python-want-logging-with-log-rotation-and-compression
    """
    def doRollover(self):
        """ do a rollover; in this case, a date/time stamp is appended to the
        filename when the rollover happens.  However, you want the file to be
        named for the start of the interval, not the current time.  If there
        is a backup count, then we have to get a list of matching file names,
        sort them and remove the one with the oldest suffix.
        """
        if self.stream:
            self.stream.close()
            self.stream = None
        if self.backupCount > 0:
            for i in range(self.backupCount - 1, 0, -1):
                sfn = '%s.%d.gz' % (self.baseFilename, i)
                dfn = '%s.%d.gz' % (self.baseFilename, i + 1)
                if os.path.exists(sfn):
                    if os.path.exists(dfn):
                        os.remove(dfn)
                    os.rename(sfn, dfn)
            dfn = self.baseFilename + '.1.gz'
            if os.path.exists(dfn):
                os.remove(dfn)
            if os.path.exists(self.baseFilename):
                with open(self.baseFilename, 'rb') as f_in:
                    with gzip.open(dfn, 'wb') as f_out:
                        f_out.writelines(f_in)
                os.remove(self.baseFilename)
        if not getattr(self, 'delay', None):
            self.stream = self._open()


def color_wrap(color, text):
    # http://stackoverflow.com/questions/287871/
    # print-in-terminal-with-colors-using-python
    if color == BgColors.GREEN:
        return BgColors.GREEN + text + BgColors.ENDC
    elif color == BgColors.RED:
        return BgColors.RED + text + BgColors.ENDC
    elif color == BgColors.BLUE:
        return BgColors.BLUE + text + BgColors.ENDC
    elif color == BgColors.YELLOW:
        return BgColors.YELLOW + text + BgColors.ENDC
    elif color == BgColors.GRAY:
        return BgColors.GRAY + text + BgColors.ENDC
    elif color == BgColors.BOLD:
        return BgColors.BOLD + text + BgColors.ENDC
    else:
        raise RuntimeError('%s is not a supported color' % color)


def get_logger(nodename, logdest, filehandler_args=None):
    """ Returns a logger for the daemon, creating it if necessary.
    :param nodename: node name
    :param logdest: log file destination
    :type logdest: LogDestination
    :param filehandler_args: dict that provides the 'filename' (mandatory),
                             'maxBytes' and 'backupCount' for the
                             rotating file handler
    :return: logger object
    """
    logger = logging.getLogger(nodename)
    lgr_fmt = '%%(asctime)s %s %%(levelname)s: %%(message)s' % nodename
    syslog_fmt = '%s: %%(levelname)s: %%(message)s' % nodename
    date_fmt = '%H:%M:%S'
    if logdest == LogDestination.SYSLOG:
        log_handler = logging.handlers.SysLogHandler(address='/dev/log')
        log_formatter = logging.Formatter(fmt=syslog_fmt)
    elif logdest == LogDestination.STDOUT:
        log_handler = logging.StreamHandler(stream=sys.stdout)
        log_formatter = logging.Formatter(lgr_fmt, date_fmt)
    elif logdest == LogDestination.LOGFILE:
        if filehandler_args is None or 'filename' not in filehandler_args:
            raise RuntimeError('Filename not provided in filehandler_args '
                               '%s' % filehandler_args)
        log_handler = _CompressedRotatingFileHandler(
            filename=filehandler_args['filename'],
            maxBytes=filehandler_args.get('maxBytes', 0),
            backupCount=filehandler_args.get('backupCount', 0))
        log_formatter = logging.Formatter(lgr_fmt, date_fmt)
    else:
        raise RuntimeError('Invalid logdest %s' % logdest)
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)
    return logger


def is_valid_ip(ip_address):
    """Returns True if this is a valid IPv4/v6 address"""
    try:
        if '/' in ip_address:
            _ = ipaddr.IPNetwork(ip_address)
        else:
            _ = ipaddr.IPAddress(ip_address)
        return True
    except Exception:
        return False


def is_valid_mac(mac_address):
    """Returns true if this is a valid MAC address"""
    return len(mac_address.split(':')) == 6


def pretty_date(input_time):
    """Get a datetime object or a int() Epoch timestamp and return a
    pretty string like 'an hour ago', 'Yesterday', '3 months ago',
    'just now', etc
    """
    if not input_time:
        return "never"

    now = datetime.utcnow()
    try:
        diff = now - datetime.utcfromtimestamp(input_time)
    except Exception:
        if isinstance(time, datetime):
            diff = now - input_time
        else:
            raise RuntimeError('Type of time (%s) is neither a timestamp or '
                               'datetime' % type(input_time))
    second_diff = diff.seconds
    day_diff = diff.days

    if day_diff < 0:
        return ''

    if day_diff == 0:
        if second_diff < 2:
            return 'just now'
        if second_diff < 60:
            return str(second_diff) + ' seconds ago'
        if second_diff < 120:
            return 'a minute ago'
        if second_diff < 3600:
            return str(second_diff / 60) + ' minutes ago'
        if second_diff < 7200:
            return 'an hour ago'
        if second_diff < 86400:
            return str(second_diff / 3600) + ' hours ago'
    if day_diff == 1:
        return 'Yesterday'
    if day_diff < 7:
        return str(day_diff) + ' days ago'
    if day_diff < 31:
        return str(day_diff / 7) + ' weeks ago'
    if day_diff < 365:
        return str(day_diff / 30) + ' months ago'
    return str(day_diff / 365) + ' years ago'


def strip_colors(text, colors=BgColors.COLORS):
    if not isinstance(text, basestring) or not colors:
        return text
    for color_idx, color in enumerate(colors):
        idx = text.find(color)
        if idx != -1:
            next_idx = text.find(BgColors.ENDC, idx)
            if next_idx != -1:
                return strip_colors(text[:idx] +
                                    text[idx + len(color):next_idx] +
                                    text[next_idx + len(BgColors.ENDC):],
                                    colors[color_idx + 1:])
    return text


def prtree(input_list, shift, top, path, final_json):
    """print a tree when provided input in the form of:
    ['a', ['b', ['c', 'd']]]
    output looks like:
    a -- b -- c
           -- d
    STP Topo, MAC Path trace and others produce output in the form
    used as input by this routine
    """
    prefixstr = ''
    printed = False
    is_leaf_node = True
    if final_json is not None:
        jsonify = True
    else:
        jsonify = False

    for fld in input_list:
        if not isinstance(fld, list):
            if top:
                if jsonify:
                    path.extend([strip_colors(fld)])
                else:
                    printstr = fld
                    sys.stdout.write(prefixstr + printstr)
                    shift += len(strip_colors(printstr))
                top = False
            else:
                if jsonify:
                    path.extend([strip_colors(fld)])
                else:
                    printstr = ' -- ' + fld
                    sys.stdout.write(prefixstr + printstr)
                    shift += len(strip_colors(printstr))
                printed = True
        else:
            is_leaf_node = False
            if not jsonify:
                sys.stdout.write(prefixstr)
                new_path = []
            else:
                # We're going to branch here. Copy existing path to new
                new_path = copy.deepcopy(path)
            printed = prtree(fld, shift, top, new_path, final_json)

            if printed:
                if not jsonify:
                    prefixstr = '\n' + ' ' * shift
            else:
                prefixstr = ''
    if jsonify:
        # In JSON, we print the entire path at the final terminating node
        if is_leaf_node:
            final_json.append(path)
        return final_json
    else:
        return printed


class ClassEncoder(JSONEncoder):

    def default(self, o):
        return o.__dict__


class NetlinkCopy(object):
    """Provides utility functions to copy values from the netlink msg to
      the python redis object.
    """

    @staticmethod
    def copy_address(dst, src, idx_to_ifname):
        # FIXME: Why is src.ifindex missing for SVI Interfaces?
        dst.ifname = idx_to_ifname.get(src.ifindex, 'None')
        dst.prefix = src.prefix
        dst.mask = src.mask
        dst.is_ipv6 = src.is_ipv6

    @staticmethod
    def copy_link(dst, src):
        dst.ifindex = src.ifindex
        dst.ifname = src.ifname
        dst.admin_state = src.admin_state
        dst.oper_state = src.oper_state
        dst.mac_address = src.mac_addr
        dst.kind = src.kind or ''
        dst.mtu = src.mtu
        # We don't copy master
        dst.localip = src.localip
        dst.dstport = src.dstport
        dst.vni = src.vni

    @staticmethod
    def copy_link_always(dst, src):
        if not dst or not src:
            return

        dst.ifindex = src.ifindex
        dst.oper_state = src.oper_state
        dst.mac_address = src.mac_addr

    @staticmethod
    def copy_macfdb(dst, src, idx_to_ifname):
        # FIXME: Why is src.ifindex missing for Bond Interfaces?
        dst.nexthop = idx_to_ifname.get(src.ifindex, 'None')
        if src.ip_address != 'None':
            dst.dst = src.ip_address
        else:
            dst.dst = ''
        if src.port is not None:
            dst.port = src.port
        else:
            dst.port = '0'
        if src.vlan is not None:
            dst.vlan = src.vlan
        else:
            dst.vlan = '0'
        dst.origin = src.family == netlink.Netlink.NUD_PERMANENT
        dst.mac_address = src.mac_address

    @staticmethod
    def copy_neighbor(dst, src, idx_to_ifname):
        # FIXME: Why is src.ifindex missing for Bond Interfaces?
        dst.ifname = idx_to_ifname.get(src.ifindex, 'None')
        dst.ip_address = src.ip_address
        dst.is_ipv6 = src.is_ipv6
        if src.mac_address is not None:
            dst.mac_address = src.mac_address

    @staticmethod
    def copy_route(dst, src, idx_to_ifname):
        dst.ip_address = src.ip_address
        dst.origin = src.origin
        dst.nexthops = [
            (str(nexthop), idx_to_ifname.get(ifindex, None))
            for nexthop, ifindex in src.nexthops
        ]
        dst.origin = not src.nexthops
        dst.protocol = src.protocol
        dst.src = src.src
        dst.is_ipv6 = src.is_ipv6
        dst.table = src.table


class Pidfile(object):
    """ Checks if another instance of the program is running.
    Explanation from http://stackoverflow.com/questions/220525/
    ensure-a-single-instance-of-an-application-in-linux
    The Right Thing is advisory locking using flock(LOCK_EX); in Python,
    this is found in the fcntl module.
    Unlike pidfiles, these locks are always automatically released when
    your process dies for any reason, have no race conditions exist
    relating to file deletion (as the file doesn't need to be deleted to
    release the lock), and there's no chance of a different process
    inheriting the PID and thus appearing to validate a stale lock.
    If you want unclean shutdown detection, you can write a marker
    (such as your PID, for traditionalists) into the file after
    grabbing the lock, and then truncate the file to 0-byte status
    before a clean shutdown (while the lock is being held); thus, if the
    lock is not held and the file is non-empty, an unclean shutdown is
    indicated.
    """
    # pylint: disable=missing-docstring
    def __init__(self, pidfile, procname, uuid=None):
        try:
            self.__pidfd = open(pidfile, 'ab+')
        except IOError as err:
            err.extra_info = 'Failed to open pidfile: %s' % pidfile
            raise
        self.__pidfile = pidfile
        self.__procname = procname
        self.__uuid = uuid

    def __str__(self):
        return self.__pidfile

    def is_running(self):
        pid = self.read()
        if pid is None:
            return False
        cmdline = '/proc/%s/cmdline' % pid
        try:
            with open(cmdline, 'r') as pidfd:
                exec_out = pidfd.readline()
            return self.__procname in exec_out and (not self.__uuid or
                                                    self.__uuid in exec_out)
        except IOError:
            return False

    def lock(self):
        try:
            fcntl.flock(self.__pidfd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except IOError:
            raise RuntimeError('Another instance of this program is already '
                               'running.')

    def read(self):
        try:
            self.__pidfd.seek(0)
            return int(self.__pidfd.readline().strip())
        except Exception:  # pylint: disable=broad-except
            return

    def unlock(self):
        try:
            fcntl.flock(self.__pidfd, fcntl.LOCK_UN)
        except IOError:
            raise RuntimeError('Unable to unlock pid file.')

    def write(self, pid):
        self.__pidfd.truncate(0)
        self.__pidfd.write('%d\n' % pid)
        self.__pidfd.flush()
