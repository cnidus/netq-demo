# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
import json
import sys

import requests

from netq.orm.objects import ORMException
from netq.orm.query import Query
from netq.orm.restapi import Connection


class RestQuery(Query):

    __URL_PREFIX = 'netq'
    __URL_VERSION = 'v1'
    __URLS = {
        'MODELS': 'models/',
        'ALL': 'models/{modelName}/all',
        'COUNT': 'models/{modelName}/count',
        'DELETE': 'models/{modelName}/delete',
        'FILTER': 'models/{modelName}/filter',
        'GET': 'models/{modelName}/get',
        'LPM': 'models/{modelName}/lpm',
        'RANGE': 'models/{modelName}/range',
        'RANGEBYSCORE': 'models/{modelName}/rangeByScore'
    }

    def __init__(self, cls):
        self.__cls = cls

    def __reversed(self, endpoint):
        return 'http://%s/%s' % (
            Connection.SERVER, '/'.join(
                (self.__URL_PREFIX, self.__URL_VERSION,
                 endpoint.format(modelName=self.__cls.__name__)))
        )

    def __load_response(self, resp):
        if resp:
            try:
                json_output = json.loads(resp)
            except Exception:
                exc_type, value, traceback = sys.exc_info()
                raise ORMException, ('Load failed', exc_type, value), traceback
            if not isinstance(json_output, list):
                json_output = [json_output]
            for json_ele in json_output:
                yield self.__cls.from_json(json_ele)

    def all(self, key_type=None, timestamp=None):
        url = self.__reversed(self.__URLS['ALL'])
        resp = requests.get(url, params={'key_type': key_type,
                                         'timestamp': timestamp})
        for ele in self.__load_response(resp.text):
            yield ele

    def count(self, keys):
        url = self.__reversed(self.__URLS['COUNT'])
        resp = requests.get(url, params={'keys': ','.join(keys)})
        for ele in json.loads(resp.text):
            yield ele

    def delete(self, key_type=None, purge=False, **kwargs):
        url = self.__reversed(self.__URLS['DELETE'])
        params = {'key_type': key_type,
                  'purge': purge}
        params.update(kwargs)
        requests.delete(url, params=params)

    def filter(self, key_type=None, timestamp=None, **kwargs):
        url = self.__reversed(self.__URLS['FILTER'])
        params = {'key_type': key_type,
                  'timestamp': timestamp}
        params.update(kwargs)
        resp = requests.get(url, params=params)
        for ele in self.__load_response(resp.text):
            yield ele

    def keys(self, key_type=None, **kwargs):
        raise NotImplementedError

    def get(self, key_type=None, timestamp=None, **kwargs):
        url = self.__reversed(self.__URLS['GET'])
        params = {'key_type': key_type,
                  'timestamp': timestamp}
        params.update(kwargs)
        resp = requests.get(url, params=params)
        return next(self.__load_response(resp.text), None)

    def latest(self, key_type=None, **kwargs):
        raise NotImplementedError

    def lpm(self, prefix, hostnames, timestamp=None, is_ipv6=False):
        url = self.__reversed(self.__URLS['LPM'])
        params = {'prefix': prefix,
                  'hostnames': ','.join(hostnames),
                  'timestamp': timestamp,
                  'is_ipv6': is_ipv6}
        resp = requests.get(url, params=params)
        for ele in self.__load_response(resp.text):
            yield ele

    def range(self, key_type=None, reverse=False, start=-1, end=-1, first=True,
              **kwargs):
        url = self.__reversed(self.__URLS['RANGE'])
        params = {'key_type': key_type,
                  'reverse': reverse,
                  'start': start,
                  'end': end,
                  'first': first}
        params.update(kwargs)
        resp = requests.get(url, params=params)
        for ele in self.__load_response(resp.text):
            yield ele

    def rangebyscore(self, key_type=None, reverse=False, start=-1, end=-1,
                     first=True, **kwargs):
        url = self.__reversed(self.__URLS['RANGEBYSCORE'])
        params = {'key_type': key_type,
                  'reverse': reverse,
                  'start': start,
                  'end': end,
                  'first': first}
        params.update(kwargs)
        resp = requests.get(url, params=params)
        for ele in self.__load_response(resp.text):
            yield ele
