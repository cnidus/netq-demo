# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.

"""
netq - Query data across all nodes in fabric

Usage:
   netq add server <ip-server>|<text-server>
   netq agent (start|stop|status|restart)
   netq [server <ip-server>|server <text-server>] check (mtu|vlan) [<hostname>] [unverified] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] check (mtu|vlan) <hostname> [<remote-interface>] [unverified] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] check (agents|bgp|clag) [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] check agents [<hostname>] history [json]
   netq [server <ip-server>|server <text-server>] resolve [around <text-time>]
   netq [server <ip-server>|server <text-server>] show info [<ip>|<ip/prefixlen>|<mac>|<hostname>|<text-asn>|<text-vlan>]
   netq [server <ip-server>|server <text-server>] show info [<ip>|<ip/prefixlen>|<mac>|<hostname>|<text-asn>|<text-vlan>] around <text-time>
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>] [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>] changes between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show interfaces [<hostname>] type (bond|bridge|eth|loopback|macvlan|swp|vlan|vxlan) [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show interfaces <hostname> [<remote-interface>] [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show lldp [<hostname>] [history]  [json]
   netq [server <ip-server>|server <text-server>] show lldp [<hostname>] [history] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show lldp <hostname> [<remote-interface>] [history] [json]
   netq [server <ip-server>|server <text-server>] show lldp <hostname> [<remote-interface>] [history] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show macs [<hostname>] [<mac>] [vlan <0-4096>] [origin] [history] [json]
   netq [server <ip-server>|server <text-server>] show macs [<hostname>] [<mac>] [vlan <0-4096>] [origin] changes between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show macs [<hostname>] [<mac>] [vlan <0-4096>]  [origin] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show macs <hostname> [nexthop <interface-nexthop>] [<mac>] [vlan <0-4096>] [origin] [history]  [json]
   netq [server <ip-server>|server <text-server>] show macs <hostname> [nexthop <interface-nexthop>] [<mac>] [vlan <0-4096>]  [origin] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show addresses [<hostname>] [<ip>|<ip/prefixlen>] changes between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show addresses [<hostname>] [<ip>|<ip/prefixlen>|<mac>] [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show addresses <hostname> [<remote-interface>] [<ip>|<ip/prefixlen>|<mac>] [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show ip routes [<hostname>] [<ipv4>|<ipv4/prefixlen>] [origin] [json]
   netq [server <ip-server>|server <text-server>] show ip routes [<hostname>] changes between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show ip routes [<hostname>] [<ipv4>|<ipv4/prefixlen>] [origin] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show ip routes [<hostname>] [<ipv4/prefixlen>] [origin] [history] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 routes [<hostname>] changes between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show ipv6 routes [<hostname>] [<ipv6/prefixlen>] [origin] [history] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 routes [<hostname>] [<ipv6>|<ipv6/prefixlen>] [origin] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show ipv6 routes [<hostname>] [<ipv6>|<ipv6/prefixlen>] [origin] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors [<hostname>] [<ipv4>] [<mac>] [history] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors [<hostname>] [<ipv4>] [<mac>] changes between <text-time> and <text-endtime> [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors [<hostname>] [<ipv4>] [<mac>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors <hostname> <remote-interface> [<ipv4>] [<mac>] [history] [json]
   netq [server <ip-server>|server <text-server>] show ip neighbors <hostname> <remote-interface> [<ipv4>] [<mac>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors [<hostname>] [<ipv6>] [<mac>] [history] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors [<hostname>] [<ipv6>] [<mac>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors <hostname> [<remote-interface>] [<ipv6>] [<mac>] [history] [json]
   netq [server <ip-server>|server <text-server>] show ipv6 neighbors <hostname> [<remote-interface>] [<ipv6>] [<mac>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] show services [<hostname>] [<text-service-name>] [history|around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show stp topology [<hostname>] [bridge <text-brname>] [around <text-time>] [json]
   netq [server <ip-server>|server <text-server>] show top_talkers (rx|tx) [errors|drops] [count <1-15>] [json]
   netq [server <ip-server>|server <text-server>] show top_talkers (rx|tx) [errors|drops] [count <1-15>] around <text-time> [json]
   netq [server <ip-server>|server <text-server>] trace l2 <mac> vlan <1-4096> from <hostname> [json]
   netq [server <ip-server>|server <text-server>] trace l3 <ip> from <hostname> [json]
   netq [server <ip-server>|server <text-server>] view <hostname> keys [json]

Options:
   add            : Update configuration
   addresses      : Interface addresses(IP or MAC) across all nodes in fabric
   agent          : Netq agent
   agents         : Check the 'liveness' of the agent across all the nodes
   around         : Go back in time to around ...
   bgp            : Check the status of all the BGP sessions across the fabric
   bridge         : Name of bridge on device
   changes        : Show changes between specified times
   check          : check health of services or correctness of parameter
   clag           : Check the status of all the CLAG daemons across the fabric
   count          : Number of entries to show
   from           : Starting at node...
   help           : Show usage info
   history        : how this infomation has changed with time
   interfaces     : Interfaces across all nodes in fabric
   ip             : IPv4 related info
   ipv6           : IPv6 related info
   json           : provide output in JSON
   info           : show information available about ...
   l2             : bridged path
   l3             : routed path
   lldp           : LLDP based neighbor info
   mac            : destination mac address to L2 path trace
   macs           : Show mac address info, with optional VLAN, across the fabric
   mtu            : Link MTU
   neighbor       : IP neighbor cache (ARP/ND) info across the fabric
   neighbors      : IP neighbor info (ARP/ND)
   origin         : owner of route
   resolve        : Annotate input with names and interesting info
   routes         : Show IPv4 route info across the fabric
   rx             : Receive
   services       : Show various system services
   show           : Show fabric-wide info
   start          : Start agent
   stop           : Stop agent
   stp            : Spanning Tree
   status         : Display agent status
   server         : Specify IP address of DB server
   top_talkers    : Top interface talkers in fabric
   topology       : Active STP topology
   trace          : Control plane trace path across fabric
   tx             : Transmit
   type           : Interface type
   unverified     : show also the unverifiable interfaces
   view           : Show output of pre-defined commands on specific node
   vlan           : VLAN
   server         : IP address of DB server
   <0-4096>       : VLAN ID
   <1-4096>       : VLAN ID, between 1-4096
   <hostname>     : Name of the remote node you want to query
   <interface-nextHop> : The name of the nexthop interface
   <ip-server>    : IP address of DB server
   <ipv4>         : IPv4 address (no mask)
   <ipv6>         : IPv6 address (no mask)
   <ip>           : IPv4 or v6 address (no mask)
   <ipv4/prefixlen> : IPv4 address with mask
   <ipv6/prefixlen> : IPv6 address with mask
   <ip/prefixlen> : IPv4 or IPv6 address with mask
   <mac>          : MAC address
   <remote-interface> : Name of the interface on the remote node
   <text-brname>  : Name of the bridge
   <text-time>    : Time string such as 10m, 30s, 1h
   <text-endtime> : Time string such as 10m, 30s, 1h
   <text-server>  : hostname of DB server (must be DNS resolvable)
   <text-asn>     : ASN you're interested in info about
   <text-vlan>    : VLAN you're interested in info about
   <text-service-name> : Name of service

Help:
    -h --help     Show this screen

"""
from __future__ import absolute_import

import bisect
import functools
import itertools
import json
import operator
import os
import socket
import subprocess
import sys
from datetime import datetime

import tabulate
from network_docopt import (
    NetworkDocopt,
    get_network_docopt_info
)

from netq.common import utils
from netq.common.enums import (
    BgColors,
    DiffState,
    Heartbeat
)
from netq.lib.netq import (
    NetQ,
    NetQException,
    AgentHealth
)

_JSON = None
_EMPTY_JSON = '[{}]'


class _MyTabulate(object):
    @staticmethod
    def __line_row(colsizes, *_):
        return ' '.join('-' * colsize for colsize in colsizes)

    @classmethod
    def __build_row(cls, colsizes, sep, cell_values, _, colaligns):
        values_with_attrs = []
        new_cell_values = []
        for cell_value, colsize, colalign in zip(cell_values,
                                                 colsizes,
                                                 colaligns):
            if colalign == 'right':
                fmt = '{0:>%d}' % colsize
            else:
                fmt = '{0:<%d}' % colsize
            key = fmt.format(cell_value.strip())
            if len(key) > colsize:
                idx = key.rfind(sep, 0, colsize)
                if idx == -1:
                    idx = colsize - 1
                new_cell_values.append(key[idx + 1:])
                key = key[:idx + 1] + ' ' * (colsize - idx - 1)
            else:
                new_cell_values.append('')
            values_with_attrs.append(key)
        line = ' '.join(values_with_attrs).rstrip()
        if any(new_cell_values):
            return line + '\n' + cls.__build_row(colsizes, sep,
                                                 new_cell_values, _,
                                                 colaligns)
        else:
            return line

    @classmethod
    def paginate(cls, data, headers, colsizes, sep=', ', first=False):
        colsizes = [max(x, len(y)) for x, y in zip(colsizes, headers)]
        linebelowheader = functools.partial(cls.__line_row, colsizes)
        headerrow = datarow = functools.partial(cls.__build_row, colsizes, sep)
        simple = tabulate.TableFormat(lineabove=None,
                                      linebelowheader=linebelowheader,
                                      linebetweenrows=None,
                                      linebelow=None,
                                      headerrow=headerrow,
                                      datarow=datarow,
                                      padding=0,
                                      with_header_hide=['lineabove',
                                                        'linebelow'])
        if first:
            return tabulate.tabulate(data, headers=headers, tablefmt=simple)
        else:
            return tabulate.tabulate(data, headers=[], tablefmt=simple)


def _build_diff(entries, state, mods):
    output = []
    for entry in entries:
        if entry is None:
            state += 1
            continue
        state_str = DiffState.MAP[state]
        if state == DiffState.MODIFIED:
            mods.append(entry)
            if len(mods) == 2:
                if mods[0][:-1] != mods[1][:-1]:
                    output.append((state_str,) + tuple(mods[0]))
                    output.append(('',) + tuple(mods[1]))
                mods[:] = []
        else:
            output.append((state_str,) + tuple(entry))
    return output, state


def _tabulate(output, headers=None, jsonify=False, first=True, colsizes=None):
    if jsonify:
        global _JSON
        out = []
        sanitized_headers = []
        _JSON = _JSON or []
        for header in headers:
            sanitized_headers.append(
                ''.join(i.lower() if idx == 0 else i.lower().title()
                        for idx, i in enumerate(header.split(' ')))
            )
        for ele in output:
            out.append(dict((key, utils.strip_colors(item))
                            for key, item in zip(sanitized_headers, ele)))
        _JSON.append(out)
    else:
        # Stringify timestamps
        new_output = []
        for row in output:
            new_ele = []
            for ele in row:
                if isinstance(ele, float):
                    try:
                        datetime.fromtimestamp(ele)
                        new_ele.append(utils.pretty_date(ele))
                        continue
                    except Exception:  # pylint: disable=broad-except
                        pass
                new_ele.append(ele)
            new_output.append(new_ele)
        if colsizes is not None:
            print _MyTabulate.paginate(new_output, headers=headers,
                                       colsizes=colsizes, first=first)
        else:
            output = tabulate.tabulate(new_output, headers)
            if first:
                print output
            else:
                print output[output.find('\n', output.find('\n') + 1) + 1:]


def _show_info(cli):
    """
    """
    mac = cli.get('<mac>') or '*'
    hostname = cli.get('<hostname>') or '*'
    asn = cli.get('<text-asn>') or '*'
    vlan = cli.get('<0-4096>')
    jsonify = cli.get('json')
    iface = '*'
    oif = '*'
    ip_address = cli.get('<ip>') or cli.get('<ip/prefixlen>') or '*'
    if vlan is not None:
        vlan = int(vlan)
    else:
        vlan = '*'

    if ip_address is not '*':
        is_ipv6 = ':' in ip_address
        first = True
        for out in cli.netq.show_addresses(hostname, iface, ip_address, mac):
            if out and not jsonify and first:
                print 'Interface Address records are'
            _tabulate(sorted(out),
                      ['IP', 'Node', 'Interface', 'Update Time'],
                      first=first,
                      jsonify=jsonify),
            first = False

        first = True
        for out in cli.netq.show_routes(ip_address, hostname, is_ipv6, False):
            if out and not jsonify and first:
                print 'Route info about prefix %s in fabric' % ip_address
            _tabulate(sorted(out),
                      ['Origin', 'Table', 'IP', 'Node',
                       'Nexthops', 'Update Time'],
                      first=first,
                      jsonify=jsonify),
            first = False

        out = cli.netq.show_router_id(ip_address)
        if out:
            if not jsonify:
                print 'List of nodes with Router ID %s' % ip_address

            _tabulate(sorted(out),
                      ['Router ID', 'Node', 'ASN', 'Protocol'], jsonify)

    elif mac is not '*':
        first = True
        for out in cli.netq.show_macvlan(mac, vlan, hostname, oif):
            if out and not jsonify and first:
                print 'List of nodes containing MAC %s' % mac
            _tabulate(sorted(out),
                      ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                       'Update Time'],
                      jsonify=jsonify,
                      first=first)
            first = False

        print cli.netq.show_info(ip_address, mac, hostname)

    elif asn is not '*':
        asn = int(asn)
        out = cli.netq.show_asn(asn)
        if out:
            if jsonify:
                print 'List of nodes with ASN %s' % asn
            _tabulate(sorted(out),
                      headers=['ASN', 'Node', 'Router ID'],
                      jsonify=jsonify)

    elif vlan is not '*':
        _ = int(vlan)

    elif hostname is not '*':
        try:
            print cli.netq.show_info(ip_address, mac, hostname)
        except NetQException as ex:
            print str(ex)


def _run(cli):
    """Once upon a time...
    """
    global _JSON
    server_addr = None

    if cli.get('server'):
        server_addr = cli.get('<ip-server>')
        if server_addr is None:
            server_name = cli.get('<text-server>')
            if server_name is not None and 'http' in server_name:
                server_addr = server_name
            else:
                try:
                    server_addr = socket.getaddrinfo(server_name, 0)[0][4][0]
                except socket.gaierror:
                    print 'Server %s is not known. Exiting' % server_name
                    sys.exit(1)

    start_time = end_time = None
    if cli.get('around') or cli.get('between'):
        start_time = cli.get('<text-time>')
    if cli.get('and'):
        end_time = cli.get('<text-endtime>')
    jsonify = cli.get('json')
    history = cli.get('history')
    diff = cli.get('changes')
    try:
        cli.netq = NetQ(server_addr, start_time, end_time)
    except: # pylint: disable=broad-except
        if jsonify:
            return _EMPTY_JSON
        raise
    netq = cli.netq

    # TESTED
    if cli.get('add'):
        if os.getuid() != 0:
            raise RuntimeError(utils.color_wrap(
                BgColors.RED, 'Please run this command as root'))
        print netq.update_config(server_addr)

    elif cli.get('agent'):
        if cli.get('start'):
            if os.getuid() != 0:
                raise RuntimeError('Please run this command as root')
            try:
                subprocess.check_output(
                    'systemctl enable netq-agent > /dev/null 2>&1',
                    shell=True
                )
                subprocess.check_output(
                    'systemctl reset-failed netq-agent'.split()
                )
                subprocess.check_output(
                    'systemctl start netq-agent'.split()
                )
                print utils.color_wrap(BgColors.GREEN, 'Success!')
            except subprocess.CalledProcessError:
                raise RuntimeError(utils.color_wrap(BgColors.RED,
                                                    'Failed to start agent'))
        elif cli.get('stop'):
            if os.getuid() != 0:
                raise RuntimeError('Please run this command as root')
            try:
                subprocess.check_output(
                    'systemctl stop netq-agent'.split()
                )
                subprocess.check_output(
                    'systemctl disable netq-agent > /dev/null 2>&1',
                    shell=True
                )
                print utils.color_wrap(BgColors.GREEN, 'Success!')
            except subprocess.CalledProcessError:
                raise RuntimeError(utils.color_wrap(BgColors.RED,
                                                    'Failed to stop agent'))
        elif cli.get('status'):
            try:
                subprocess.check_output('systemctl status netq-agent'.split())
                print utils.color_wrap(BgColors.GREEN, 'Running...')
            except subprocess.CalledProcessError as ex:
                print utils.color_wrap(BgColors.RED, 'Stopped...')
                return ex.returncode
        elif cli.get('restart'):
            if os.getuid() != 0:
                raise RuntimeError('Please run this command as root')
            try:
                subprocess.check_output(
                    'systemctl enable netq-agent > /dev/null 2>&1',
                    shell=True
                )
                subprocess.check_output(
                    'systemctl reset-failed netq-agent'.split()
                )
                subprocess.check_output(
                    'systemctl restart netq-agent'.split()
                )
                print utils.color_wrap(BgColors.GREEN, 'Success!')
            except subprocess.CalledProcessError:
                raise RuntimeError(utils.color_wrap(BgColors.RED,
                                                    'Failed to restart agent'))
    elif cli.get('check'):
        if cli.get('vlan'):
            hostname = cli.get('<hostname>') or '*'
            ifname = cli.get('<remote-interface>')  # we want this to be not '*'
            unverified = cli.get('unverified')

            out_json = []
            try:
                unverified_lst, pvid_mismatch, output = (
                    netq.check_vlan_consistency(hostname, ifname)
                )
            except NetQException, error:
                if jsonify:
                    print '[{"error": "%s"}]' % error
                else:
                    print utils.color_wrap(BgColors.RED, '%s' % error)
                return

            if (unverified and unverified_lst) or pvid_mismatch or output:
                if not output and not pvid_mismatch:
                    if not jsonify:
                        print utils.color_wrap(BgColors.GREEN,
                                               'No mismatched links found')
                else:
                    if output:
                        if not jsonify:
                            print utils.color_wrap(BgColors.RED,
                                                   'Vlan mismatch found on '
                                                   'following links')
                        _tabulate(output,
                                  headers=['Node', 'Interface', 'Vlans',
                                  'Peer', 'Interface', 'Peer Vlans'],
                                  jsonify=jsonify)
                        # We have to convert the JSON above into something more
                        #  and save it since we have multiple prints and we
                        # want to incorporate them all into one big JSON string
                        if jsonify:
                            out_json.append([{'reason': 'Vlan mismatch',
                                              'nodes': _JSON[0]}])
                            _JSON = None
                    if pvid_mismatch:
                        if not jsonify:
                            print utils.color_wrap(BgColors.RED,
                                                   'PVID mismatch found on '
                                                   'following links')
                        _tabulate(pvid_mismatch,
                                  headers=['Node', 'Interface', 'PVID',
                                           'Peer', 'Interface', 'Peer PVID'],
                                  jsonify=jsonify)
                        if jsonify:
                            out_json.append([{'reason': 'PVID mismatch',
                                              'nodes': _JSON[0]}])
                            _JSON=None

                if unverified and unverified_lst:
                    if not jsonify:
                        print utils.color_wrap(BgColors.RED,
                                               'Vlan check could not be done '
                                               'on:')
                    _tabulate(unverified_lst,
                              headers=['Node', 'Interface', 'Vlans', 'Peer',
                                       'Interface'],
                              jsonify=jsonify)
                    if jsonify:
                        out_json.append([{'reason': 'Unverified',
                                          'nodes': _JSON[0]}])
                if jsonify:
                    _JSON = out_json
            else:
                if not jsonify:
                    print utils.color_wrap(BgColors.GREEN,
                                           'No mismatched links found')
                else:
                    print _EMPTY_JSON

        elif cli.get('agents'):
            if history:
                hostname = cli.get('<hostname>') or '*'
                out = []
                restarts = 0
                for key, grouper in itertools.groupby(
                        netq.show_agent_history(hostname=hostname),
                        key=operator.itemgetter(0)
                ):
                    items = sorted(grouper, key=operator.itemgetter(1))
                    if len(items) > 1:
                        restarts = len(items) - 1
                        color = BgColors.RED
                    else:
                        restarts = 0
                        color = BgColors.GREEN

                    last_beat = (datetime.utcnow() -
                                 datetime.utcfromtimestamp(int(items[-1][2])))
                    if last_beat.total_seconds() > Heartbeat.HEARTBEAT_DEATH:
                        cur_color = BgColors.RED
                    elif (last_beat.total_seconds() <=
                          Heartbeat.LIVELINESS_RATE):
                        cur_color = BgColors.GREEN
                    else:
                        cur_color = BgColors.YELLOW

                    if hostname != '*':
                        # Provide detailed output for this scenario
                        for item in items:
                            ts1 = item[1]
                            if not jsonify:
                                ts1 = datetime.utcfromtimestamp(int(ts1))
                            out.append([key, str(ts1)])
                    else:
                        ts1 = items[0][1]
                        ts2 = items[-1][1]
                        if not jsonify:
                            ts1 = datetime.utcfromtimestamp(int(ts1))
                            ts2 = datetime.utcfromtimestamp(int(ts2))
                        out.append([utils.color_wrap(color, key),
                                    str(ts1),
                                    utils.color_wrap(cur_color, str(ts2)),
                                    utils.color_wrap(color, '%d' % restarts)])

                if hostname == '*':
                    _tabulate(out,
                              headers=['Node', 'First Connect time',
                                       'Last Connect Time',
                                       'NumRestarts'], jsonify=jsonify)
                else:
                    if not jsonify and restarts:
                        print utils.color_wrap(BgColors.RED,
                                               'Number of Restarts: %d' %
                                               restarts)
                    _tabulate(out, headers=['Node', 'Connect Time'],
                              jsonify=jsonify)
            else:
                out = netq.show_status()
                new_out = []
                for nodename, ts1, ts2, status in out:
                    if status == AgentHealth.ROTTEN:
                        new_status = utils.color_wrap(BgColors.RED, 'Rotten')
                    elif status == AgentHealth.STALE:
                        new_status = utils.color_wrap(BgColors.YELLOW,
                                                      'Stale')
                    else:
                        new_status = utils.color_wrap(BgColors.GREEN, 'Fresh')
                    if jsonify:
                        bisect.insort(new_out,
                                      (nodename, ts1, ts2, new_status))
                    else:
                        bisect.insort(new_out,
                                      (nodename,
                                       datetime.utcfromtimestamp(int(ts1)),
                                       ts2,
                                       new_status))
                _tabulate(new_out,
                          headers=['Node Name', 'Connect Time',
                                   'Last Connect', 'Status'],
                          jsonify=jsonify)

        elif cli.get('bgp'):
            good_out, out = netq.check_bgp_status()
            if jsonify:
                failed_cnt = len(out)
                out += good_out
                total_cnt = len(out)
            else:
                failed_cnt = len(out)
                total_cnt = len(good_out) + failed_cnt

            ts = cli.get('<text-time>') or None
            col_headers = ['Node', 'Neighbor', 'Peer ID', 'Reason', 'Time']
            if ts:
                timestr = utils.color_wrap(BgColors.BLUE,
                                           'Output retrieved around %s' %
                                           ts)
            if not total_cnt:
                if not jsonify:
                    print 'No BGP session info found'
                else:
                    print _EMPTY_JSON
                return
            elif failed_cnt:
                if not jsonify:
                    print utils.color_wrap(BgColors.RED,
                                           'Total Sessions: %d , '
                                           'Failed Sessions: %d ' %
                                           (total_cnt, failed_cnt))
                if out:
                    _tabulate([(utils.color_wrap(BgColors.RED, hostname),
                                utils.color_wrap(BgColors.RED, nbr),
                                utils.color_wrap(BgColors.RED, peerid),
                                utils.color_wrap(BgColors.RED, reason),
                                utils.color_wrap(BgColors.RED,
                                                 utils.pretty_date(rst_time /
                                                                   1000)))
                               for hostname, nbr, peerid, reason, rst_time in
                               sorted(out)],
                              headers=col_headers,
                              jsonify=jsonify)
            else:
                if not jsonify:
                    print utils.color_wrap(
                        BgColors.GREEN,
                        'Total Sessions: %d, Failed Sessions: 0' %
                        total_cnt)
                else:
                    _tabulate(sorted(out), headers=col_headers, jsonify=jsonify)

        elif cli.get('clag'):
            col_headers = ['Failed Node', 'Reason']
            good_node_lst, failed_node_lst = netq.check_clag_status()

            if jsonify:
                failed_cnt = len(failed_node_lst)
                failed_node_lst += good_node_lst
                total_cnt = len(failed_node_lst)
            else:
                failed_cnt = len(failed_node_lst)
                total_cnt = len(good_node_lst) + failed_cnt

            if not total_cnt:
                if not jsonify:
                    print 'No CLAG session info found'
            elif not failed_cnt:
                if not jsonify:
                    print utils.color_wrap(BgColors.GREEN,
                                           'Checked Nodes: %d, Failed Nodes: 0 '
                                           % total_cnt)
            else:
                if not jsonify:
                    print utils.color_wrap(BgColors.RED,
                                           'Checked Nodes: %d, '
                                           'Failed Nodes: %d ' % (total_cnt,
                                                                  failed_cnt))
            if failed_cnt or jsonify:
                new_failed_node_list = []
                for nodename, err_str in failed_node_lst:
                    if isinstance(err_str, list):
                        err_str = ', '.join(err_str)
                    if err_str:
                        new_failed_node_list.append(
                            (nodename, utils.color_wrap(BgColors.RED, err_str))
                        )
                    else:
                        new_failed_node_list.append((nodename, ''))
                colsizes = [16, 64]
                _tabulate(sorted(new_failed_node_list),
                          headers=col_headers,
                          colsizes=colsizes,
                          jsonify=jsonify)

    elif cli.get('resolve'):
        if not sys.stdin.isatty():
            print netq.resolve_output()

    elif cli.get('trace'):
        if cli.get('l2'):
            output = netq.path_trace_mac(cli.get('<mac>'),
                                         cli.get('<1-4096>'),
                                         cli.get('<hostname>'))
        elif cli.get('l3'):
            output = netq.path_trace_route(cli.get('<ip>'),
                                           cli.get('<hostname>'))
        else:
            return

        if jsonify:
            flattened_paths = []
        else:
            flattened_paths = None
        utils.prtree(output, 0, True, [], flattened_paths)
        if jsonify:
            print json.dumps(flattened_paths)
        else:
            print

    elif cli.get('view'):
        hostname = cli.get('<hostname>')
        if cli.get('keys'):
            _tabulate(sorted(netq.show_keys(hostname)),
                      ['Key', 'Oldest', 'Newest', 'Count'],
                      jsonify=jsonify)
        else:
            argv = cli.argv_expanded
            # Taking the hostname into account
            startidx = argv.index('view') + 2
            endidx = None
            if cli.get('around'):
                endidx = argv.index('around')
            try:
                ts, output = netq.view(hostname, argv[startidx:endidx])
                print '\n'.join([
                    utils.color_wrap(BgColors.RED, 'Output retrieved from %s' %
                                     utils.pretty_date(ts)), output
                ])
            except NetQException as ex:
                print str(ex)

    elif cli.get('show'):
        if cli.get('info'):
            _show_info(cli)

        elif cli.get('interfaces'):
            hostname = cli.get('<hostname>') or '*'
            interface = cli.get('<remote-interface>') or '*'
            kind = (
                cli.get('bond') or cli.get('bridge') or cli.get('macvlan') or
                cli.get('vlan') or cli.get('eth') or cli.get('loopback') or
                cli.get('swp') or cli.get('vxlan') or '*'
            )
            if history:
                headers = ['Node', 'Interface', 'State', 'Details',
                           'Present', 'Update Time']
                colsizes = [16, 12, 5, 27, 5, 15]

                out = netq.show_link_history(hostname, interface, kind)
                if out:
                    _tabulate(out, headers, jsonify=jsonify, colsizes=colsizes)
                else:
                    if not jsonify:
                        print 'No matching Link found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['Node', 'Interface', 'Type', 'Link', 'Details',
                           'Update Time']
                colsizes = [15, 15, 8, 4, 28, 10]
                first = True
                if diff:
                    state = DiffState.ADDED
                    mods = []
                    for out in netq.show_links(hostname, interface, kind):
                        entries, state = _build_diff(out, state, mods)
                        if entries:
                            _tabulate(entries,
                                      ['Type'] + headers,
                                      jsonify=jsonify,
                                      first=first,
                                      colsizes=[12] + colsizes)
                            first = False
                    if first:
                        if not jsonify:
                            print 'No changes detected'
                        else:
                            print _EMPTY_JSON
                else:
                    for out in netq.show_links(hostname, interface, kind):
                        _tabulate(sorted(out), headers, jsonify=jsonify,
                                  first=first, colsizes=colsizes)
                        first = False
                    if first:
                        if not jsonify:
                            print 'No matching Links found'
                        else:
                            print _EMPTY_JSON

        elif cli.get('lldp'):
            node = cli.get('<hostname>') or '*'
            iface = cli.get('<remote-interface>') or '*'
            out = netq.show_neighbors(node, iface)
            if out:
                if not jsonify:
                    if node is not None:
                        if iface is not None:
                            print 'LLDP peer info for %s:%s' % (node, iface)
                        else:
                            print 'LLDP Peer Info for %s' % node
                    else:
                        print 'LLDP Info for fabric'
                _tabulate(sorted(out),
                          headers=['Node', 'Interface', 'LLDP Peer',
                                   'Peer Int', 'Update Time'],
                          jsonify=jsonify)
            else:
                if not jsonify:
                    print 'No LLDP record found'
                else:
                    print _EMPTY_JSON

        elif cli.get('macs'):
            mac = cli.get('<mac>') or '*'
            vlan = cli.get('<0-4096>')
            if vlan is not None:
                vlan = int(vlan)
            else:
                vlan = '*'

            hostname = cli.get('<hostname>') or '*'
            oif = cli.get('<interface-nexthop>') or '*'
            origin = 'origin' == cli.get('origin') or '*'

            first=True

            if diff:
                state = DiffState.ADDED
                mods = []
                headers = ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                           'Origin', 'Update Time']
                colsizes = [20, 8, 12, 16, 4, 14]
                for out in netq.show_macvlan(mac, vlan, hostname, oif,
                                             origin):
                    entries, state = _build_diff(out, state, mods)
                    if entries:
                        _tabulate(entries,
                                  ['Type'] + headers,
                                  jsonify=jsonify,
                                  first=first,
                                  colsizes=[6] + colsizes)
                        first = False
                if first:
                    if not jsonify:
                        print 'No changes detected'
                    else:
                        print _EMPTY_JSON

                return

            if history:
                entries = netq.show_mac_history(mac, vlan, hostname, oif,
                                                origin)
                headers = ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                           'Origin', 'Update Time', 'Present']
                colsizes = [20, 8, 12, 16, 4, 14, 6]
            else:
                headers = ['MAC', 'VLAN', 'Node Name', 'Egress Port',
                           'Origin', 'Update Time']
                colsizes = [20, 8, 12, 16, 4, 16]
                entries = netq.show_macvlan(mac, vlan, hostname, oif, origin)

            for out in entries:
                if not jsonify and first:
                    if vlan != '*':
                        print(
                        'List of nodes containing MAC %s in '
                        'VLAN %s' % (mac, vlan)
                        )

                print 'List of nodes containing MAC %s' % mac
                _tabulate(sorted(out), headers=headers, jsonify=jsonify,
                          first=first, colsizes=colsizes)
                first = False

                if first:
                    if not jsonify:
                        print 'No matching MAC entry found'
                    else:
                        print _EMPTY_JSON

        elif cli.get('addresses'):
            node = cli.get('<hostname>') or '*'
            iface = cli.get('<remote-interface>') or '*'
            ip_address = cli.get('<ip>') or cli.get('<ip/prefixlen>') or '*'
            mac = cli.get('<mac>') or '*'

            if history:
                out = netq.show_address_history(node, iface, ip_address, mac)
                if out:
                    headers = ['Address', 'Node', 'Interface', 'Present',
                               'Update Time']

                    _tabulate(out, headers, jsonify=jsonify)
                else:
                    if not jsonify:
                        print 'No matching Address found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['Address', 'Node', 'Interface', 'Update Time']
                colsizes = [28, 12, 20, 16]
                first = True
                if diff:
                    state = DiffState.ADDED
                    mods = []
                    for out in netq.show_addresses(node, iface, ip_address,
                                                   mac):
                        entries, state = _build_diff(out, state, mods)
                        if entries:
                            _tabulate(entries,
                                      ['Type'] + headers,
                                      jsonify=jsonify,
                                      first=first,
                                      colsizes=[12] + colsizes)
                            first = False
                    if first:
                        if not jsonify:
                            print 'No changes detected'
                        else:
                            print _EMPTY_JSON
                else:
                    for out in netq.show_addresses(node, iface, ip_address,
                                                   mac):
                        if not jsonify and first:
                            print 'Matching interface Address records are'
                        _tabulate(sorted(out),
                                  headers,
                                  jsonify=jsonify,
                                  first=first,
                                  colsizes=colsizes)
                        first = False
                    if first:
                        if not jsonify:
                            print 'No matching Interface Address entry found'
                        else:
                            print _EMPTY_JSON

        elif cli.get('services'):
            hostname = cli.get('<hostname>') or '*'
            svcname = cli.get('<text-service-name>') or '*'

            out = netq.get_services_status(hostname, svcname)
            _tabulate(sorted(out),
                      ['Node', 'Service', 'Enabled', 'Active', 'Monitored',
                       'Timestamp'],
                      jsonify=jsonify)

        elif cli.get('stp'):
            brname = cli.get('<text-brname>') or '*'
            hostname = cli.get('<hostname>') or '*'

            if jsonify:
                flattened_paths = []
            else:
                flattened_paths = None

            try:
                stpmap = netq.get_stp_topo(hostname, brname, True)
            except Exception as ex:
                print utils.color_wrap(BgColors.RED, str(ex))
            else:
                if stpmap:
                    utils.prtree(stpmap, 0, True, [], flattened_paths)
                    if jsonify:
                        print json.dumps(flattened_paths)
                    else:
                        print

        elif cli.get('routes'):
            hostname = cli.get('<hostname>') or '*'
            if cli.get('ip'):
                ip_address = (
                    cli.get('<ipv4>') or cli.get('<ipv4/prefixlen>') or '*'
                )
                is_ipv6 = False
            else:
                ip_address = (
                    cli.get('<ipv6>') or cli.get('<ipv6/prefixlen>') or '*'
                )
                is_ipv6 = True
            if cli.get('origin'):
                origin = True
            else:
                origin = '*'
            if history:
                out = netq.show_route_history(ip_address,
                                              hostname,
                                              ipv6=is_ipv6)
                if out:
                    _tabulate(out,
                              ['IP', 'Node', 'Nexthops', 'Origin',
                               'Present', 'Update Time'],
                              jsonify=jsonify)
                else:
                    if not jsonify:
                        print 'No matching route found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['Origin', 'Table', 'IP', 'Node', 'Nexthops',
                           'Update Time']
                if is_ipv6:
                    colsizes = [3, 3, 32, 16, 25, 16]
                else:
                    colsizes = [3, 3, 16, 16, 25, 16]
                first = True
                if diff:
                    state = DiffState.ADDED
                    mods = []
                    for out in netq.show_routes(ip_address, hostname, is_ipv6,
                                                origin):
                        entries, state = _build_diff(out, state, mods)
                        if entries:
                            _tabulate(entries,
                                      ['Type'] + headers,
                                      jsonify=jsonify,
                                      first=first,
                                      colsizes=[12] + colsizes)
                            first = False
                    if first:
                        if not jsonify:
                            print 'No changes detected'
                        else:
                            print _EMPTY_JSON
                else:
                    for out in netq.show_routes(ip_address, hostname, is_ipv6,
                                                origin):
                        if not jsonify and first:
                            if ip_address:
                                if hostname:
                                    print('Route info about prefix %s on '
                                          'host %s' % (ip_address, hostname))
                                else:
                                    print('Route info about prefix %s in '
                                          'fabric' % ip_address)
                            elif hostname:
                                print 'Routes in host %s FIB' % hostname
                            else:
                                print 'List of all routes in fabric'
                        # Print routes with origin first
                        _tabulate(sorted(out),
                                  headers,
                                  jsonify=jsonify,
                                  first=first,
                                  colsizes=colsizes)
                        first = False
                    if first:
                        if not jsonify:
                            print 'No matching routes found'
                        else:
                            print _EMPTY_JSON

        elif cli.get('neighbors'):
            if cli.get('ip'):
                ip_address = cli.get('<ipv4>') or '*'
                is_ipv6 = False
            else:
                ip_address = cli.get('<ipv6>') or '*'
                is_ipv6 = True

            mac = cli.get('<mac>') or '*'
            hostname = cli.get('<hostname>') or '*'
            iface = cli.get('<remote-interface>') or '*'
            if history:
                out = netq.show_ip_neighbor_history(hostname=hostname,
                                                    ip_address=ip_address,
                                                    ifname=iface,
                                                    mac=mac,
                                                    ipv6=is_ipv6)
                if out:
                    _tabulate(out,
                              ['IP', 'Node', 'Interface', 'MAC',
                               'Present', 'Update Time'],
                              jsonify)
                else:
                    if not jsonify:
                        print 'No IP neighbor entry found'
                    else:
                        print _EMPTY_JSON
            else:
                headers = ['IP', 'Node', 'Interface', 'MAC', 'Update Time']
                colsizes = [16, 16, 20, 24, 16]
                first = True
                if diff:
                    state = DiffState.ADDED
                    mods = []
                    for out in netq.show_ip_neighbors(ip_address, hostname,
                                                      iface, mac, is_ipv6):
                        entries, state = _build_diff(out, state, mods)
                        if entries:
                            _tabulate(entries,
                                      ['Type'] + headers,
                                      jsonify=jsonify,
                                      first=first,
                                      colsizes=[12] + colsizes)
                            first = False
                    if first:
                        if not jsonify:
                            print 'No changes detected'
                        else:
                            print _EMPTY_JSON
                else:
                    for out in netq.show_ip_neighbors(ip_address, hostname,
                                                      iface, mac, is_ipv6):
                        if not jsonify and first:
                            if ip_address is not '*':
                                print 'IP Neighbor info for %s' % ip_address
                            else:
                                print 'IP Neighbor Info for fabric'
                        _tabulate(sorted(out),
                                  headers,
                                  jsonify=jsonify,
                                  first=first,
                                  colsizes=colsizes)
                        first = False
                    if first:
                        if not jsonify:
                            print 'No IP neighbor entry found'
                        else:
                            print _EMPTY_JSON

        elif cli.get('top_talkers'):
            show_rx = cli.get('rx')
            show_errors = cli.get('errors')
            show_drops = cli.get('drops')
            count = cli.get('<1-15>') or 5
            if show_rx:
                api = netq.top_talkers_rx
            else:
                api = netq.top_talkers_tx
            output = api(count)
            if show_errors:
                if not output['if_err_bps']:
                    if not jsonify:
                        print 'No interfaces with errors'
                    else:
                        print _EMPTY_JSON
                else:
                    if not jsonify and output['if_err_ts']:
                        print utils.color_wrap(
                            BgColors.RED,
                            'Output retrieved from %s' %
                            utils.pretty_date(output['if_err_ts'])
                        )
                    _tabulate(output['if_err_bps'], ['Nodename', 'Ifname',
                                                     'Error Rate(bps)'],
                              jsonify)
            elif show_drops:
                if not output['if_drop_bps']:
                    if not jsonify:
                        print 'No interfaces with drops'
                    else:
                        print _EMPTY_JSON
                else:
                    if not jsonify and output['if_drop_ts']:
                        print(
                            utils.color_wrap(
                                BgColors.RED,
                                'Output retrieved from %s' %
                                utils.pretty_date(output['if_drop_ts'])
                            )
                        )
                    _tabulate(output['if_drop_bps'], ['Nodename', 'Ifname',
                                                      'Drop Rate(bps)'],
                              jsonify)
            else:
                if not output['if_bps']:
                    if not jsonify:
                        print 'Not available'
                    else:
                        print _EMPTY_JSON
                else:
                    if not jsonify and output['if_ts']:
                        print utils.color_wrap(
                            BgColors.RED,
                            'Output retrieved from %s' %
                            utils.pretty_date(output['if_ts'])
                        )
                    _tabulate(output['if_bps'],
                              ['Nodename', 'Ifname', 'Rate(bps)'],
                              jsonify)


def _view_complete(argv, doc):
    """ Hack to remove <wildcard> hacks from network docopt
    """
    view_idx = next((idx for idx, arg in enumerate(argv) if arg == 'view'),
                    None)
    if view_idx is not None and len(argv) >= view_idx + 2:
        choices = NetQ.view_complete(argv[view_idx + 1])
        aroundstring = ' around <text-time>'
        viewstring = ('   netq [server <ip-server>|server <text-server>] '
                      'view <hostname> {key}')
        usage_idx = doc.find('Usage:')
        options_idx = doc.find('Options:')
        pre_usage = doc[:usage_idx]
        usage = doc[usage_idx:options_idx].rstrip('\n')
        post_usage = doc[options_idx:]
        new_usage = '%s\n%s\n%s\n' % (usage,
                                      '\n'.join([viewstring.format(key=choice)
                                                 for choice in choices]),
                                      '\n'.join([viewstring.format(key=choice)
                                                 + aroundstring
                                                 for choice in choices]))
        return pre_usage + new_usage + post_usage
    return doc


def main():
    (print_options, ended_with_space, sys.argv) = (
        get_network_docopt_info(sys.argv)
    )

    cli = NetworkDocopt(_view_complete(sys.argv, __doc__))

    # Add custom completers
    cli.add_tag_matcher('<hostname>', NetQ.hostname_match, True)
    cli.add_tab_complete_hook('<hostname>', NetQ.hostname_complete)
    cli.add_tag_matcher('<remote-interface>', NetQ.interface_match, True)
    cli.add_tab_complete_hook('<remote-interface>', NetQ.interface_complete)
    cli.add_tag_matcher('<interface-nexthop>', NetQ.interface_match, True)
    cli.add_tab_complete_hook('<interface-nexthop>', NetQ.interface_complete)
    cli.add_tag_matcher('<text-service-name>', NetQ.generic_match, True)

    try:
        if print_options:
            cli.print_options(ended_with_space)
        else:
            cli.run(argv=[sys.argv[0]] + (sys.argv[1:] or ['check',
                                                           'agents']))
            out = _run(cli)
            if _JSON:
                print json.dumps(_JSON)
            elif _JSON is not None:
                print _EMPTY_JSON
            return out
    except IOError as e:
        # stdout is closed, no point in continuing
        # Attempt to close them explicitly to prevent cleanup problems:
        if str(e).lower() == 'broken pipe':
            exit(0)
        try:
            sys.stdout.close()
        except IOError:
            pass
        try:
            sys.stderr.close()
        except IOError:
            pass
