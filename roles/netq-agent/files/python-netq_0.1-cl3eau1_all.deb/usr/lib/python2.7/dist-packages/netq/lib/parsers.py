# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

import json
import subprocess
import time
from glob import glob

from netq.common.enums import (
    Daemons,
    RunningService
)
from netq.orm import HOSTNAME
from netq.orm.memdb.models import (
    Lldp
)
from netq.orm.redisdb.models import (
    BgpSession,
    ClagSession,
    MstpInfo,
    Services)


def build_lldp_summary(hostname, timestamp, cmd_output):
    try:
        json_op = json.loads(cmd_output)
    except ValueError:
        return

    for key, values in json_op.iteritems():
        for value in values:
            try:
                for lldp in value['interface']:
                    lldpobj = Lldp()
                    lldpobj.hostname = hostname
                    lldpobj.timestamp = timestamp

                    try:
                        lldpobj.ifname = str(lldp['name'])
                        lldpobj.peer_hostname = str(
                            lldp['chassis'][0]['name'][0]['value']
                        )
                        if '.' in lldpobj.peer_hostname:
                            lldpobj.peer_hostname = (
                                lldpobj.peer_hostname.split('.')[0]
                            )
                        lldpobj.peer_ifname = str(
                            lldp['port'][0]['id'][0]['value']
                        )

                        for cap in lldp['chassis'][0]['capability']:
                            if cap['type'] == 'Bridge':
                                lldpobj.lldp_peer_bridge = cap['enabled']
                            elif cap['type'] == 'Router':
                                lldpobj.lldp_peer_router = cap['enabled']

                        lldpobj.lldp_peer_os = str(
                            lldp['chassis'][0]['descr'][0]['value']
                        )
                    except Exception:
                        continue
                    else:
                        lldpobj.save()
            except Exception:
                continue


def get_bond_members(name):
    """Get members of a bond
    """
    try:
        with open('/sys/class/net/%s/bonding/slaves' % name, 'r') as fd:
            return fd.readline().strip().split()
    except IOError:
        return []


def get_bridge_members(name):
    """Get members of a bridge
    """
    mbrs = []
    out = glob('/sys/class/net/%s/brif/*' % name)
    for entry in out:
        mbrs.append(entry.split('/')[-1].encode('ascii', 'ignore'))

    return mbrs


def is_bridge_vlan_filtering(name):
    """Determine if this bridge is a vlan filtering bridge or not
    """
    try:
        with open('/sys/class/net/%s/bridge/vlan_filtering' % name, 'r') as fd:
            return int(fd.readline().strip()) == 1
    except IOError:
        return False


def process_bgp_neighbors(output):
    """Build summary of BGP node info, such as ASN & RID
    """
    try:
        json_out = json.loads(output)
    except ValueError:
        return

    now_ms = int(time.time() * 1000)

    for key in json_out:
        session = json_out[key]
        bgp_nbr = BgpSession()
        bgp_nbr.peer_name = key.encode('ascii', 'ignore')
        bgp_nbr.state = session['bgpState'].encode('ascii', 'ignore')
        bgp_nbr.peer_router_id = (
            session['remoteRouterId'].encode('ascii', 'ignore')
        )
        bgp_nbr.peer_asn = session['remoteAs']
        bgp_nbr.peer_hostname = session.get('hostname', '').encode('ascii', 'ignore')
        bgp_nbr.asn = int(session['localAs'])
        bgp_nbr.reason = 'N/A'
        afi_session = session['addressFamilyInfo']
        if 'lastResetDueTo' in afi_session:
            bgp_nbr.reason = (
                afi_session['lastResetDueTo'].encode('ascii', 'ignore')
            )
            bgp_nbr.last_reset_time = (
                int(now_ms - afi_session['lastResetTimerMsecs'])
            )
        else:
            bgp_nbr.last_reset_time = 0
        if 'IPv4 Unicast' in session['addressFamilyInfo']:
            bgp_nbr.ipv4_pfx_rcvd = (
                int(afi_session['IPv4 Unicast']['acceptedPrefixCounter'])
            )
        else:
            bgp_nbr.ipv4_pfx_rcvd = 0
        if 'IPv6 Unicast' in session['addressFamilyInfo']:
            bgp_nbr.ipv6_pfx_rcvd = (
                int(afi_session['IPv6 Unicast']['acceptedPrefixCounter'])
            )
        else:
            bgp_nbr.ipv6_pfx_rcvd = 0
        bgp_nbr.conn_dropped = afi_session['connectionsDropped']
        bgp_nbr.conn_estd = afi_session['connectionsEstablished']
        bgp_nbr.save()


def process_clagctl(cmd_output):
    """Build clag info for node
    """
    try:
        json_out = json.loads(cmd_output)
    except ValueError:
        return

    if 'errorMsg' in json_out:
        return

    clag_conflicted_bonds = []
    clag_singly_attached_bonds = []
    clag_dual_attached_bonds = []
    clag_proto_down_bonds = []
    dual_attach_bonds = {}

    clag_session = ClagSession()

    clag_session.peer_state = json_out['status']['peerAlive']

    clag_session.peer_if = (
        json_out['status']['peerIf'].encode('ascii', 'ignore')
    )
    clag_session.peer_role = json_out['status']['peerRole'].encode('ascii',
                                                                    'ignore')
    clag_session.role = json_out['status']['ourRole'].encode('ascii', 'ignore')
    clag_session.clag_sysmac = json_out['status']['sysMac'].encode('ascii',
                                                                   'ignore')
    clag_session.backup_ip = (
        json_out['status']['backupIp'].encode('ascii', 'ignore')
    )

    for iface in json_out['clagIntfs']:
        if json_out['clagIntfs'][iface]['status'] == 'dual':
            dual_attach_bonds[iface] = json_out['clagIntfs'][iface]['peerIf']
        else:
            clag_singly_attached_bonds.append(iface)
        if 'conflicts' in json_out['clagIntfs'][iface]:
            clag_conflicted_bonds.append(
                [iface,
                 json_out['clagIntfs'][iface]['conflicts'][0].
                 encode('ascii', 'ignore')]
            )
        if 'protoDown' in json_out['clagIntfs'][iface]:
            string = (
                json_out['clagIntfs'][iface]['protoDown'][0].encode('ascii',
                                                                    'ignore')
            )
            clag_proto_down_bonds.append([iface, string])

    clag_session.conflicted_bonds = clag_conflicted_bonds
    clag_session.single_bonds = clag_singly_attached_bonds
    clag_session.proto_down_bonds = clag_proto_down_bonds
    clag_session.dual_bonds = dual_attach_bonds

    # If the CLAG sysmac changed, we need to delete the older entry.
    m_clag_session = ClagSession.memmodel()
    for entry in m_clag_session.query.filter(hostname=HOSTNAME):
        if entry.clag_sysmac != clag_session.clag_sysmac:
            old_clag_entry = ClagSession()
            old_clag_entry.copy(entry)
            old_clag_entry.delete()
    clag_session.save()


def process_ospf_neighbors(cmd_output):
    """Process OSPF neighbors info
    """
    # Not yet
    return


def process_mstpall(cmd_output):
    """Build mstp info for node
    """
    try:
        json_out = json.loads(cmd_output)
    except ValueError:
        return

    now = int(time.time())

    for key in json_out:
        bridge = json_out[key][key]
        mstp_session = MstpInfo()
        edge_ports = []
        network_ports = []
        disputed_ports = []
        bpduguard_ports = []
        bpduguard_err_ports = []
        bpdufilter_ports = []
        ba_inconsistent_ports = []
        ports = {}

        mstp_session.bridge_name = key.encode('ascii', 'ignore')
        if 'rootPortName' in bridge:
            mstp_session.root_port_name = (
                bridge['rootPortName'].encode('ascii', 'ignore')
            )
        mstp_session.root_bridge = bridge['dsgnRoot'].encode('ascii',
                                                             'ignore').lower()
        mstp_session.topo_chg_ports = [
            bridge['topoChngPort'].encode('ascii', 'ignore'),
            bridge['lastTopoChngPort'].encode('ascii', 'ignore')
        ]
        mstp_session.topo_chg_cntr = bridge['topoChngCounter']
        mstp_session.bridge_id = bridge['bridgeId'].encode('ascii',
                                                           'ignore').lower()
        mstp_session.time_since_tcn = (
            now - int(bridge['timeSinceLastTopoChng'])
        )
        mstp_session.is_vlan_filtering = is_bridge_vlan_filtering(key)

        for port in json_out[key]:
            if port == key or port == 'bridgeIndex':
                continue

            # All the following sections assume that the key exists only if the
            # value is True. This is the current behavior of mstpctl.
            for portId in json_out[key][port]:
                portinfo = json_out[key][port][portId]
                if 'operEdgePort' in portinfo:
                    edge_ports.append(port)
                if 'networkPort' in portinfo:
                    network_ports.append(port)
                if 'baInconsistent' in portinfo:
                    ba_inconsistent_ports.append(port)
                if 'bpduGuardPort' in portinfo:
                    bpduguard_ports.append(port)
                if 'bpduGuardError' in portinfo:
                    bpduguard_err_ports.append(port)
                if 'disputed' in portinfo:
                    disputed_ports.append(port)
                if 'bpduFilterPort' in portinfo:
                    bpdufilter_ports.append(port)

                ports[port] = {}
                ports[port]['role'] = portinfo['role']
                ports[port]['state'] = portinfo['state']
                ports[port]['clagDualConnMac'] = (
                    portinfo['clagDualConnMac'].lower()
                )
                ports[port]['sendRstp'] = portinfo['allInformation']['sendRstp']
                ports[port]['clagIsl'] = 'clagIsl' in portinfo or False

        mstp_session.edge_ports = edge_ports
        mstp_session.network_ports = network_ports
        mstp_session.disputed_ports = disputed_ports
        mstp_session.bpduguard_ports = bpduguard_ports
        mstp_session.bpduguard_err_ports = bpduguard_err_ports
        mstp_session.bpdufilter_ports = bpdufilter_ports
        mstp_session.ba_inconsistent_ports = ba_inconsistent_ports
        mstp_session.ports = ports

        mstp_session.save()


def process_systemctl(cmd_out):
    lines = cmd_out.splitlines()
    lineno = 0
    total_lines = len(lines)
    mcls = Services.memmodel()
    while lineno < total_lines:
        # Assumed format is the following for each systemctl entry:
        # Names=ssh.service
        # ActiveState=active
        # UnitFileState=enabled
        # <blank line>
        if not lines[lineno]:
            break
        name = lines[lineno].split('=')[1].split('.')[0]
        is_active = lines[lineno + 1].split('=')[1].strip() == 'active'
        is_enabled = (
            lines[lineno + 2].split('=')[1].strip() == 'enabled'
        )
        if name == RunningService.QUAGGA:
            quagga_daemons = [Daemons.BGPD, Daemons.OSPFD,
                              Daemons.OSPF6D, Daemons.ZEBRA]
            for daemon in quagga_daemons:
                newsvc = Services()
                oldsvc = mcls.query.get(hostname=HOSTNAME, name=daemon)
                if is_active:
                    cmdstr = (
                        '/usr/bin/sudo vtysh -d %s -c quit' % daemon
                    )
                    try:
                        subprocess.check_output(cmdstr)
                    except Exception:  # pylint: disable=broad-except
                        pass
                if oldsvc:
                    newsvc.copy(oldsvc)
                else:
                    newsvc.name = daemon
                newsvc.is_active = 0
                newsvc.is_enabled = is_enabled
                newsvc.save()
        else:
            newsvc = Services()
            oldsvc = mcls.query.get(hostname=HOSTNAME, name=name)
            if oldsvc:
                newsvc.copy(oldsvc)
            else:
                newsvc.name = name
            newsvc.is_active = is_active
            newsvc.is_enabled = is_enabled
            newsvc.save()
        lineno += 4
