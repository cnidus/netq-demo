# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
import itertools
import sys
import time

import redis
from redis import WatchError
from redis.client import StrictPipeline, StrictRedis
from redis.exceptions import (
    ConnectionError,
    NoScriptError,
    ResponseError,
    TimeoutError,
)

_RETRY_LIMIT = 6


class RedisException(Exception):

    def __init__(self, *args, **kwargs):
        super(RedisException, self).__init__(*args, **kwargs)


class MyStrictRedis(StrictRedis):

    def execute_command(self, *args, **options):
        """Execute a command and return a parsed response
        """
        pool = self.connection_pool
        command_name = args[0]
        timeout = 1
        for retry in range(_RETRY_LIMIT + 1):
            connection = pool.get_connection(command_name, **options)
            try:
                connection.send_command(*args)
                output = self.parse_response(connection, command_name,
                                             **options)
                return output
            except (ConnectionError, TimeoutError, ResponseError) as ex:
                connection.disconnect()
                if isinstance(ex, NoScriptError):
                    raise
                if retry == _RETRY_LIMIT:
                    exc_type, value, traceback = sys.exc_info()
                    raise RedisException, ('execute_command failed',
                                           exc_type, value), traceback
            finally:
                try:
                    pool.release(connection)
                except:
                    pass
            timeout *= 2
            time.sleep(timeout)


class MyStrictPipeline(StrictPipeline):

    def execute(self, raise_on_error=True):
        """Execute all the commands in the current pipeline
        ** EVENTLET FRIENDLY VERSION ***
        """
        stack = self.command_stack
        if not stack:
            return []
        if self.transaction or self.explicit_transaction:
            execute = self._execute_transaction
        else:
            execute = self._execute_pipeline
        timeout = 1
        for retry in range(_RETRY_LIMIT + 1):
            conn = (
                self.connection_pool.get_connection('MULTI',
                                                    self.shard_hint)
            )
            try:
                if self.scripts:
                    self.load_scripts()
                output = execute(conn, stack, raise_on_error)
                self.scripts = set()
                return output
            except (ConnectionError, TimeoutError, ResponseError):
                conn.disconnect()
                if retry == _RETRY_LIMIT:
                    exc_type, value, traceback = sys.exc_info()
                    raise RedisException, ('pipeline execute failed',
                                           exc_type, value), traceback
                # if we were watching a variable, the watch is no longer valid
                # since this connection has died. raise a WatchError, which
                # indicates the user should retry his transaction. If this is
                # more than a temporary failure, the WATCH that the user next
                # issues will fail, propagating the real ConnectionError
                if self.watching:
                    raise WatchError('A ConnectionError occurred on while '
                                     'watching one or more keys')
            finally:
                self.connection = conn
                self.my_reset()
            # In a monkey patched environment, eventlet monkey patches
            # time.sleep by default.
            timeout *= 2
            time.sleep(timeout)

    def immediate_execute_command(self, *args, **options):
        """Execute a command immediately, but don't auto-retry on a
        ConnectionError if we're already WATCHing a variable. Used when
        issuing WATCH or subsequent commands retrieving their values but before
        MULTI is called.
        ** EVENTLET FRIENDLY VERSION ***
        """
        command_name = args[0]
        timeout = 1
        for retry in range(_RETRY_LIMIT + 1):
            conn = (
                self.connection_pool.get_connection(command_name,
                                                    self.shard_hint)
            )
            try:
                conn.send_command(*args)
                output = self.parse_response(conn, command_name, **options)
                self.command_stack = []
                self.scripts = set()
                return output
            except (ConnectionError, TimeoutError, ResponseError) as ex:
                conn.disconnect()
                if isinstance(ex, NoScriptError):
                    raise
                if retry == _RETRY_LIMIT:
                    exc_type, value, traceback = sys.exc_info()
                    raise RedisException, ('pipeline immediate_execute failed',
                                           exc_type, value), traceback
                if self.watching:
                    raise WatchError('A ConnectionError occurred on while '
                                     'watching one or more keys')
            finally:
                self.connection = conn
                self.my_reset()
            # In a monkey patched environment, eventlet monkey patches
            # time.sleep by default.
            timeout *= 2
            time.sleep(timeout)

    def load_scripts(self):
        # make sure all scripts that are about to be run on this pipeline exist
        scripts = list(self.scripts)
        immediate = self.immediate_execute_command
        shas = {s.sha for s in scripts}
        # we can't use the normal script_* methods because they would just
        # get buffered in the pipeline.
        exists = immediate('SCRIPT', 'EXISTS', *shas, **{'parse': 'EXISTS'})
        if not all(exists):
            for s, exist in itertools.izip(scripts, exists):
                if not exist:
                    s.sha = immediate('SCRIPT', 'LOAD', s.script,
                                      **{'parse': 'LOAD'})

    def my_reset(self):
        # make sure to reset the connection state in the event that we were
        # watching something
        if self.watching and self.connection:
            try:
                # call this manually since our unwatch or
                # immediate_execute_command methods can call reset()
                self.connection.send_command('UNWATCH')
                self.connection.read_response()
            except ConnectionError:
                # disconnect will also remove any previous WATCHes
                self.connection.disconnect()
        # clean up the other instance attributes
        self.watching = False
        self.explicit_transaction = False
        # we can safely return the connection to the pool here since we're
        # sure we're no longer WATCHing anything
        if self.connection:
            try:
                self.connection_pool.release(self.connection)
            except:
                pass
            self.connection = None


class Connection(object):

    PIPE = None
    REDIS = None
    SERVER = None

    def __init__(self):
        raise NotImplementedError

    @classmethod
    def get_pipeline(cls):
        return cls.PIPE

    @classmethod
    def new_pipeline(cls):
        cls.PIPE = MyStrictPipeline(cls.REDIS.connection_pool,
                                    cls.REDIS.response_callbacks,
                                    transaction=False,
                                    shard_hint=None)

    @classmethod
    def new_redis(cls):
        cls.REDIS = MyStrictRedis(cls.SERVER)

    @classmethod
    def new_strict_redis(cls):
        cls.REDIS = StrictRedis(cls.SERVER)


def curr_pipeline():
    return Connection.PIPE


def new_pipeline():
    Connection.new_pipeline()


def ping_server(server):
    redis.StrictRedis(server, socket_connect_timeout=2).ping()


def reset_connection_settings():
    Connection.PIPE.reset()
    Connection.new_redis()
    Connection.new_pipeline()


def set_connection_settings(server, agent=False):
    if server is None:
        raise RuntimeError('Please provide a valid address for the server')
    Connection.SERVER = server.split('/')[0]
    if not agent:
        Connection.new_strict_redis()
    else:
        Connection.new_redis()
    Connection.new_pipeline()


