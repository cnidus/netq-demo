# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.


class AvlNode(object):
    """A node in an AVL tree.
    """
    def __init__(self, score, value):
        self.score = score
        self.value = value
        self.left = None
        self.right = None

    def __repr__(self):
        return '%s(score=%s, value=%s)' % (self.__class__.__name__,
                                           self.score,
                                           self.value)


class AvlTree(object):
    """An AVL tree.
    """
    def __init__(self):
        # Root node of the tree.
        self.node = None
        # Height of the tree.
        self.height = -1
        # Balance factor of the tree.
        self.balance = 0

    def __repr__(self):
        return '%s(score=%s, value=%s)' % (self.__class__.__name__,
                                           self.node.score,
                                           self.node.value)

    def __is_unique(self, value):
        return all(value != tree.node.value
                   for tree in self.inorder()
                   if tree.node is not None)

    def __range(self, func, start, end, score_cast_func, withscores):
        nodes = [tree.node for tree in self.inorder() if tree.node is not None]
        if start is None:
            start = 0
        if end is None:
            end = len(nodes)
        for node in func(nodes[start:end]):
            if withscores:
                yield node.value, score_cast_func(node.score)
            else:
                yield node.value

    def __rangebyscore(self, func, start, end, score_cast_func, withscores):
        nodes = [tree.node for tree in self.inorder() if tree.node is not None]
        for node in func(nodes):
            if start <= node.score <= end:
                if withscores:
                    yield node.value, score_cast_func(node.score)
                else:
                    yield node.value

    def __rebalance(self):
        """Rebalance tree. After inserting or deleting a node,
        it is necessary to check each of the node's ancestors for consistency
        with the rules of AVL.
        """
        # Check if we need to rebalance the tree
        #   update height
        #   balance tree
        self.__update_heights(recursive=False)
        self.__update_balances(False)

        # For each node checked, if the balance factor remains -1, 0 or +1
        # then no rotations are necessary.
        while self.balance < -1 or self.balance > 1:
            # Left subtree is larger than right subtree
            if self.balance > 1:

                # Left Right Case -> rotate y,z to the left
                if self.node.left.balance < 0:
                    #     x               x
                    #    / \             / \
                    #   y   D           z   D
                    #  / \        ->   / \
                    # A   z           y   C
                    #    / \         / \
                    #   B   C       A   B
                    self.node.left.__rotate_left()
                    self.__update_heights()
                    self.__update_balances()

                # Left Left Case -> rotate z,x to the right
                #       x                 z
                #      / \              /   \
                #     z   D            y     x
                #    / \         ->   / \   / \
                #   y   C            A   B C   D
                #  / \
                # A   B
                self.__rotate_right()
                self.__update_heights()
                self.__update_balances()

            # Right subtree is larger than left subtree
            if self.balance < -1:

                # Right Left Case -> rotate x,z to the right
                if self.node.right.balance > 0:
                    #     y               y
                    #    / \             / \
                    #   A   x           A   z
                    #      / \    ->       / \
                    #     z   D           B   x
                    #    / \                 / \
                    #   B   C               C   D
                    self.node.right.__rotate_right()  # we're in case III
                    self.__update_heights()
                    self.__update_balances()

                # Right Right Case -> rotate y,x to the left
                #       y                 z
                #      / \              /   \
                #     A   z            y     x
                #        / \     ->   / \   / \
                #       B   x        A   B C   D
                #          / \
                #         C   D
                self.__rotate_left()
                self.__update_heights()
                self.__update_balances()

    def __rotate_left(self):
        """
        Left rotation
            set self as the left subtree of right subree
        """
        new_root = self.node.right.node
        new_left_sub = new_root.left.node
        old_root = self.node
        self.node = new_root
        old_root.right.node = new_left_sub
        new_root.left.node = old_root

    def __rotate_right(self):
        """Right rotation
           set self as the right subtree of left subree
        """
        new_root = self.node.left.node
        new_left_sub = new_root.right.node
        old_root = self.node
        self.node = new_root
        old_root.left.node = new_left_sub
        new_root.right.node = old_root

    def __update_balances(self, recursive=True):
        """Calculate tree balance factor
        The balance factor is calculated as follows:
            balance = height(left subtree) - height(right subtree).
        """
        if self.node is not None:
            if recursive:
                if self.node.left is not None:
                    self.node.left.__update_balances()
                if self.node.right is not None:
                    self.node.right.__update_balances()
            self.balance = self.node.left.height - self.node.right.height
        else:
            self.balance = 0

    def __update_heights(self, recursive=True):
        """Update tree height
        Tree height is max height of either left or right subtrees +1 for root
        of the tree
        """
        if self.node is not None:
            if recursive:
                if self.node.left is not None:
                    self.node.left.__update_heights()
                if self.node.right is not None:
                    self.node.right.__update_heights()
            self.height = 1 + max(self.node.left.height,
                                  self.node.right.height)
        else:
            self.height = -1

    def empty(self):
        return self.node is None

    def inorder(self):
        """Inorder traversal of the tree
           Left subree + root + Right subtree
        """
        if self.node is None:
            return
        if self.node.left is not None:
            for tree in self.node.left.inorder():
                yield tree
        yield self
        if self.node.right is not None:
            for tree in self.node.right.inorder():
                yield tree

    def insert(self, score, value):
        """Insert new key into node
        """
        if not self.__is_unique(value):
            return
            # Create new node
        n = AvlNode(score, value)
        # Initial tree
        if self.node is None:
            self.node = n
            self.node.left = AvlTree()
            self.node.right = AvlTree()
        # Insert key to the left subtree
        elif score < self.node.score:
            self.node.left.insert(score, value)
        # Insert key to the right subtree
        elif score > self.node.score:
            self.node.right.insert(score, value)
        # Rebalance tree if needed
        self.__rebalance()

    def remove(self, score):
        """Delete key from the tree
        Let node X be the node with the value we need to delete,
        and let node Y be a node in the tree we need to find to take node X's
        place, and let node Z be the actual node we take out of the tree.

        Steps to consider when deleting a node in an AVL tree are the
        following:
            * If node X is a leaf or has only one child, skip to step 5. (node
              Z will be node X)
                * Otherwise, determine node Y by finding the largest node in
                  node X's left sub tree (in-order predecessor) or the smallest
                  in its right sub tree (in-order successor).
                * Replace node X with node Y (remember, tree structure doesn't
                  change here, only the values). In this step, node X is
                  essentially deleted when its internal values were
                  overwritten with node Y's.
                * Choose node Z to be the old node Y.
            * Attach node Z's subtree to its parent (if it has a subtree). If
              node Z's parent is null, update root. (node Z is currently root)
            * Delete node Z.
            * Retrace the path back up the tree (starting with node Z's
              parent) to the root, adjusting the balance factors as needed.
        """
        if self.node is not None:
            if self.node.score == score:
                # Key found in leaf node, just erase it
                if (self.node.left.node is None and
                        self.node.right.node is None):
                    self.node = None
                # Node has only one subtree (right), replace root with that one
                elif self.node.left.node is None:
                    self.node = self.node.right.node
                # Node has only one subtree (left), replace root with that one
                elif self.node.right.node is None:
                    self.node = self.node.left.node
                else:
                    # Find  successor as smallest node in right subtree or
                    #       predecessor as largest node in left subtree
                    successor = self.node.right.node
                    while successor and successor.left.node is not None:
                        successor = successor.left.node
                    if successor is not None:
                        self.node.score = successor.score
                        # Delete successor from the replaced node right subree
                        self.node.right.remove(successor.score)
            elif score < self.node.score:
                self.node.left.remove(score)
            elif score > self.node.score:
                self.node.right.remove(score)
            # Rebalance tree
            self.__rebalance()

    def latest(self, score_cast_func=float, withscores=False):
        right = self
        while right is not None:
            right = right.right
        if withscores:
            return right.value, score_cast_func(right.score)
        else:
            return right.value

    def range(self, start=None, end=None, score_cast_func=float,
              withscores=True):
        for val in self.__range(iter, start, end, score_cast_func,
                                withscores):
            yield val

    def revrange(self, start=None, end=None, score_cast_func=float,
                 withscores=True):
        for val in self.__range(reversed, start, end, score_cast_func,
                                withscores):
            yield val

    def rangebyscore(self, start=None, end=None, score_cast_func=float,
                     withscores=True):
        for val in self.__rangebyscore(iter, start, end, score_cast_func,
                                       withscores):
            yield val

    def revrangebyscore(self, start=None, end=None, score_cast_func=float,
                        withscores=True):
        for val in self.__rangebyscore(reversed, end, start, score_cast_func,
                                       withscores):
            yield val
