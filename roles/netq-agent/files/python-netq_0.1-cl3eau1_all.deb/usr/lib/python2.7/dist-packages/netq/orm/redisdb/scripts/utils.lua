-- vim: tabstop=4 shiftwidth=4 softtabstop=4
-- Copyright 2016 Cumulus Networks, Inc. All rights reserved.
--
-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; either version 2
-- of the License, or (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc.
-- 51 Franklin Street, Fifth Floor
-- Boston, MA  02110-1301, USA
local function _mysplit(inputstr, sep)
    local fields={}
    local pattern = string.format("([^%s]+)", sep)
    for str in string.gmatch(inputstr, pattern) do
        fields[#fields + 1] = str
    end
    return fields
end

local function _get_ipv6_subnet(ip, mask)
    local tmp = 128
    local tmptbl = _mysplit(ip, ":")
    local op = {}
    for idx = 1, #tmptbl do
        if tmp - 16 >= mask then
            op[#op + 1] = tonumber(tmptbl[idx], 16)
        elseif tmp > mask and tmp - 16 < mask then
	    local netmask = 0
	    for idx1 = 16, 16 - (tmp - mask), -1 do
            netmask = bit.bor(netmask, bit.blshift(1, idx1))
        end
            op[#op + 1] = bit.band(tonumber(tmptbl[idx], 16), netmask)
        else
            op[#op + 1] = 0
        end
        tmp = tmp - 16
    end
    return table.concat(op, ':', 1, #op)
end

local function _ipv4tonumber(input)
    local ip1, ip2, ip3, ip4 = string.match(
        input,
        "(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)"
    )
    return 2 ^ 24 * ip1 + 2 ^ 16 * ip2 + 2 ^ 8 * ip3 + ip4
end

local function _is_ipv4_match(prefix1, prefix2, mask)
    local prefix_number = _ipv4tonumber(prefix1)
    local input_number = _ipv4tonumber(prefix2)
    local netmask = 0
    for i = 32 - mask, 32 do
        netmask = bit.bor(netmask, bit.blshift(1, i))
    end
    return bit.band(prefix_number, netmask) ==
           bit.band(input_number, netmask)
end

local function expand_ipv6(ip)
    local first, last = string.match(ip, "(.*)::(.*)")
    if first == nil then
       first = ip
    end
    -- Initialize result
    local res = {}
    for idx=1, 8 do
       res[idx] = 0
    end

    local tmptbl
    local mul = 1
    tmptbl = _mysplit(first, ":")
    for idx = 1, #tmptbl do
       res[mul] = tmptbl[idx]
       mul = mul + 1
    end
    mul = 8
    if last ~= nil then
       tmptbl = _mysplit(last, ":")
       for idx = #tmptbl, 1, -1 do
       	   res[mul] = tmptbl[idx]
	   mul = mul - 1
       end
    end
    return table.concat(res, ':', 1, #res)
end

local function _is_ipv6_match(ip1, ip2, mask)
    return _get_ipv6_subnet(expand_ipv6(ip1), mask) ==
           _get_ipv6_subnet(expand_ipv6(ip2), mask)
end

local function is_match(prefix1, prefix2, mask, is_ipv6)
    if is_ipv6 == 1 then
        return _is_ipv6_match(prefix1, prefix2, mask)
    else
        return _is_ipv4_match(prefix1, prefix2, mask)
    end
end

local function sub_prefix(input, is_ipv6)
    if input == "*" then
        return input
    elseif is_ipv6 == 1 then
        return string.gsub(input, "(%:?[0-9a-fA-F]+%*?)$", "*")
    else
        return string.gsub(input, "(%.?%d%d?%d?%*?)$", "*")
    end
end

local utils = {
    -- utility func
    expand_ipv6 = expand_ipv6,
    is_match = is_match,
    sub_prefix = sub_prefix,
}
